/**
 * Blog With Sports (BWS) - Standalone Editorial & SEO Admin Portal
 * Direct Firebase Firestore Cloud Integration
 * Pure Vanilla JavaScript ES6 - Zero Build Setup
 */

(function () {
  'use strict';

  // 1. Firebase Credentials provided by User
  const firebaseConfig = {
    apiKey: "AIzaSyDnxfGsSAW7-flKMQiBPHAmx2W7DACdOR0",
    authDomain: "lg-topup.firebaseapp.com",
    projectId: "lg-topup",
    storageBucket: "lg-topup.firebasestorage.app",
    messagingSenderId: "897901681283",
    appId: "1:897901681283:web:04486e9fd22e2190c059b6",
    measurementId: "G-0Z0VHECHZR"
  };

  const STORAGE_KEY = 'bws_articles_v3';
  const CATEGORIES_KEY = 'bws_categories_v1';
  const ARTICLES_COLLECTION = 'articles';
  const ANALYTICS_COLLECTION = 'analytics';

  // Default Categories
  const DEFAULT_CATEGORIES = [
    { id: 'football', name: 'Football' },
    { id: 'basketball', name: 'Basketball' },
    { id: 'tennis', name: 'Tennis' },
    { id: 'motorsport', name: 'Motorsport' },
    { id: 'cricket', name: 'Cricket' },
    { id: 'baseball', name: 'Baseball' },
    { id: 'nfl', name: 'NFL' },
    { id: 'athletics', name: 'Athletics' },
    { id: 'golf', name: 'Golf' },
    { id: 'combat-sports', name: 'Combat Sports' }
  ];

  // Stock Verified Sports Image Presets
  const IMAGE_PRESETS = {
    football: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=1200&auto=format&fit=crop&q=80',
    basketball: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=1200&auto=format&fit=crop&q=80',
    tennis: 'https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=1200&auto=format&fit=crop&q=80',
    motorsport: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=1200&auto=format&fit=crop&q=80',
    cricket: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=1200&auto=format&fit=crop&q=80',
    baseball: 'https://images.unsplash.com/photo-1508344928928-7165b67de128?w=1200&auto=format&fit=crop&q=80'
  };

  // State
  let db = null;
  let articles = [];
  let categories = [...DEFAULT_CATEGORIES];
  let editingArticleId = null;
  let siteAnalytics = { totalPageviews: 0, uniqueVisits: 0 };

  // DOM Elements
  const el = {
    totalArticles: document.getElementById('statTotalArticles'),
    publishedArticles: document.getElementById('statPublishedArticles'),
    draftArticles: document.getElementById('statDraftArticles'),
    totalVisitors: document.getElementById('statTotalVisitors'),
    visitorDetails: document.getElementById('statVisitorDetails'),
    articlesTableBody: document.getElementById('articlesTableBody'),
    emptyState: document.getElementById('emptyState'),
    tableCard: document.getElementById('tableCard'),
    searchInput: document.getElementById('searchInput'),
    categoryFilter: document.getElementById('categoryFilter'),
    statusFilter: document.getElementById('statusFilter'),
    articleModal: document.getElementById('articleModal'),
    modalTitle: document.getElementById('modalTitle'),
    articleForm: document.getElementById('articleForm'),
    titleInput: document.getElementById('articleTitle'),
    slugInput: document.getElementById('articleSlug'),
    dynamicUrlPreview: document.getElementById('dynamicUrlPreview'),
    categorySelect: document.getElementById('articleCategory'),
    authorInput: document.getElementById('articleAuthor'),
    authorRoleInput: document.getElementById('articleAuthorRole'),
    imageInput: document.getElementById('articleImage'),
    imagePreview: document.getElementById('imagePreview'),
    captionInput: document.getElementById('articleCaption'),
    descriptionInput: document.getElementById('articleDescription'),
    contentInput: document.getElementById('articleContent'),
    seoKeywords: document.getElementById('seoKeywords'),
    seoTitle: document.getElementById('seoTitle'),
    seoMetaDesc: document.getElementById('seoMetaDesc'),
    googlePreviewTitle: document.getElementById('googlePreviewTitle'),
    googlePreviewUrl: document.getElementById('googlePreviewUrl'),
    googlePreviewSnippet: document.getElementById('googlePreviewSnippet'),
    featuredCheckbox: document.getElementById('articleIsFeatured'),
    trendingCheckbox: document.getElementById('articleIsTrending'),
    toastContainer: document.getElementById('toastContainer'),
    jsonFileInput: document.getElementById('jsonFileInput')
  };

  // Initialize Firebase & Dashboard
  function init() {
    initFirebase();
    populateCategorySelects();
    setupEventListeners();
    loadLocalFallback();
    listenToFirestore();
    listenToAnalytics();
    render();
  }

  // Init Firebase Firestore
  function initFirebase() {
    try {
      if (typeof firebase !== 'undefined') {
        if (!firebase.apps.length) {
          firebase.initializeApp(firebaseConfig);
        }
        db = firebase.firestore();
        console.log('Firebase Firestore initialized successfully for project:', firebaseConfig.projectId);
      } else {
        console.warn('Firebase SDK not loaded, operating in local offline mode.');
      }
    } catch (e) {
      console.error('Firebase initialization error:', e);
    }
  }

  // Real-time Firestore articles listener
  function listenToFirestore() {
    if (!db) return;
    try {
      db.collection(ARTICLES_COLLECTION).onSnapshot((snapshot) => {
        const remoteArticles = [];
        snapshot.forEach((doc) => {
          remoteArticles.push({ id: doc.id, ...doc.data() });
        });

        articles = remoteArticles;
        // Also update local cache
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(articles));
        } catch {}

        render();
      }, (error) => {
        console.warn('Firestore real-time articles listener warning:', error);
      });
    } catch (e) {
      console.warn('Could not establish Firestore listener:', e);
    }
  }

  // Real-time Visitor & Analytics listener
  function listenToAnalytics() {
    if (!db) return;
    try {
      db.collection(ANALYTICAL_COLLECTION || ANALYTICS_COLLECTION).doc('traffic').onSnapshot((doc) => {
        if (doc.exists) {
          const data = doc.data();
          siteAnalytics.totalPageviews = data.totalPageviews || 0;
          siteAnalytics.uniqueVisits = data.uniqueVisits || 0;
        }
        updateAnalyticsUI();
      }, (err) => {
        console.warn('Analytics snapshot error:', err);
      });
    } catch (e) {
      console.warn('Could not attach analytics listener:', e);
    }
  }

  // Local storage fallback
  function loadLocalFallback() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        articles = JSON.parse(stored);
      }
    } catch (e) {
      articles = [];
    }
  }

  // Populate category options
  function populateCategorySelects() {
    if (!el.categorySelect || !el.categoryFilter) return;

    el.categoryFilter.innerHTML = '<option value="all">All Categories</option>';
    categories.forEach(cat => {
      const opt = document.createElement('option');
      opt.value = cat.id;
      opt.textContent = cat.name;
      el.categoryFilter.appendChild(opt);
    });

    el.categorySelect.innerHTML = '';
    categories.forEach(cat => {
      const opt = document.createElement('option');
      opt.value = cat.id;
      opt.textContent = cat.name;
      el.categorySelect.appendChild(opt);
    });
  }

  // Reading Time calculation
  function calculateReadingTime(text) {
    if (!text) return '1 min read';
    const words = text.trim().split(/\s+/).length;
    const minutes = Math.max(1, Math.ceil(words / 200));
    return `${minutes} min read`;
  }

  // Generate clean SEO-friendly slug
  function generateSlug(text) {
    return text
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/[\s_-]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  // Render Dashboard
  function render() {
    updateStats();
    updateAnalyticsUI();
    renderArticlesTable();
  }

  // Update article KPI counts
  function updateStats() {
    const total = articles.length;
    const published = articles.filter(a => a.status === 'published').length;
    const drafts = articles.filter(a => a.status === 'draft').length;

    if (el.totalArticles) el.totalArticles.textContent = total;
    if (el.publishedArticles) el.publishedArticles.textContent = published;
    if (el.draftArticles) el.draftArticles.textContent = drafts;
  }

  // Update Analytics & Visitor KPI UI
  function updateAnalyticsUI() {
    if (!el.totalVisitors) return;
    const views = siteAnalytics.totalPageviews;
    const uniques = siteAnalytics.uniqueVisits;

    el.totalVisitors.textContent = views.toLocaleString();
    if (el.visitorDetails) {
      el.visitorDetails.textContent = `${uniques.toLocaleString()} unique visitors · ${views.toLocaleString()} pageviews`;
    }
  }

  // Render Articles Table with Filter
  function renderArticlesTable() {
    if (!el.articlesTableBody) return;

    const searchTerm = (el.searchInput ? el.searchInput.value : '').toLowerCase().trim();
    const catFilter = el.categoryFilter ? el.categoryFilter.value : 'all';
    const stFilter = el.statusFilter ? el.statusFilter.value : 'all';

    const filtered = articles.filter(art => {
      const tagsStr = (art.tags || []).join(' ').toLowerCase();
      const keywordsStr = (art.seo?.keywords || []).join(' ').toLowerCase();

      const matchesSearch =
        !searchTerm ||
        art.title.toLowerCase().includes(searchTerm) ||
        (art.description && art.description.toLowerCase().includes(searchTerm)) ||
        (art.authorName && art.authorName.toLowerCase().includes(searchTerm)) ||
        tagsStr.includes(searchTerm) ||
        keywordsStr.includes(searchTerm);

      const matchesCat = catFilter === 'all' || art.categoryId === catFilter;
      const matchesStatus = stFilter === 'all' || art.status === stFilter;

      return matchesSearch && matchesCat && matchesStatus;
    });

    if (filtered.length === 0) {
      el.tableCard.style.display = 'none';
      el.emptyState.style.display = 'block';
      return;
    }

    el.tableCard.style.display = 'block';
    el.emptyState.style.display = 'none';

    el.articlesTableBody.innerHTML = filtered.map(art => {
      const isPub = art.status === 'published';
      const viewsCount = (art.views || 0).toLocaleString();
      const dynamicUrl = `/#article/${art.slug}`;

      return `
        <tr>
          <td>
            <img 
              src="${art.featuredImage || IMAGE_PRESETS.football}" 
              alt="${escapeHtml(art.title)}" 
              class="cell-thumb" 
              onerror="this.src='https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=1200&auto=format&fit=crop&q=80'"
            />
          </td>
          <td>
            <div class="cell-title">${escapeHtml(art.title)}</div>
            <div class="cell-slug" title="Dynamic URL created on website">${dynamicUrl}</div>
          </td>
          <td>
            <span class="badge badge-category">${art.categoryName || art.categoryId}</span>
            ${art.isFeatured ? '<span class="badge badge-featured">Spotlight</span>' : ''}
          </td>
          <td>${escapeHtml(art.authorName || 'BWS Editorial')}</td>
          <td>${viewsCount} views</td>
          <td>
            <span class="badge ${isPub ? 'badge-published' : 'badge-draft'}">
              ${art.status}
            </span>
          </td>
          <td>
            <div class="actions-cell">
              <button class="btn btn-outline btn-sm" onclick="BWSAdmin.editArticle('${art.id}')">
                Edit &amp; SEO
              </button>
              <button class="btn btn-outline btn-sm" onclick="BWSAdmin.toggleStatus('${art.id}')">
                ${isPub ? 'Draft' : 'Publish'}
              </button>
              <button class="btn btn-danger btn-sm" onclick="BWSAdmin.deleteArticle('${art.id}')">
                Delete
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  // Update SEO Snippet Preview
  function updateSEOSnippetPreview() {
    const title = el.titleInput.value.trim() || 'Article Title';
    const slug = el.slugInput.value.trim() || generateSlug(title);
    const seoTitle = el.seoTitle.value.trim() || `${title} | Blog With Sports`;
    const desc = el.seoMetaDesc.value.trim() || el.descriptionInput.value.trim() || 'Article summary excerpt will appear here on Google...';

    if (el.dynamicUrlPreview) {
      el.dynamicUrlPreview.textContent = `/#article/${slug}`;
    }
    if (el.googlePreviewTitle) {
      el.googlePreviewTitle.textContent = seoTitle;
    }
    if (el.googlePreviewUrl) {
      el.googlePreviewUrl.textContent = `https://blogwithsports.com › article › ${slug}`;
    }
    if (el.googlePreviewSnippet) {
      el.googlePreviewSnippet.textContent = desc.substring(0, 160);
    }
  }

  // Open Modal for New Article
  function openNewArticleModal() {
    editingArticleId = null;
    el.modalTitle.textContent = 'Create New Sports Story & Dynamic Page';
    el.articleForm.reset();

    // Default values
    el.authorInput.value = 'BWS Editorial';
    el.authorRoleInput.value = 'Senior Desk & Research Team';
    el.imageInput.value = IMAGE_PRESETS.football;
    el.imagePreview.src = IMAGE_PRESETS.football;
    el.seoKeywords.value = '';
    el.seoTitle.value = '';
    el.seoMetaDesc.value = '';

    updateSEOSnippetPreview();
    el.articleModal.classList.add('active');
  }

  // Open Modal for Edit Article
  function editArticle(id) {
    const art = articles.find(a => a.id === id);
    if (!art) return;

    editingArticleId = id;
    el.modalTitle.textContent = 'Edit Article & SEO Details';

    el.titleInput.value = art.title || '';
    el.slugInput.value = art.slug || '';
    el.categorySelect.value = art.categoryId || 'football';
    el.authorInput.value = art.authorName || 'BWS Editorial';
    el.authorRoleInput.value = art.authorRole || 'Senior Desk';
    el.imageInput.value = art.featuredImage || '';
    el.imagePreview.src = art.featuredImage || IMAGE_PRESETS.football;
    el.captionInput.value = art.featuredImageCaption || '';
    el.descriptionInput.value = art.description || '';
    el.contentInput.value = art.content || '';
    el.featuredCheckbox.checked = Boolean(art.isFeatured);
    el.trendingCheckbox.checked = Boolean(art.isTrending);

    // SEO Fields
    const keywordsArr = art.seo?.keywords || art.tags || [];
    el.seoKeywords.value = keywordsArr.join(', ');
    el.seoTitle.value = art.seo?.seoTitle || '';
    el.seoMetaDesc.value = art.seo?.metaDescription || art.description || '';

    updateSEOSnippetPreview();
    el.articleModal.classList.add('active');
  }

  // Save Article (Create or Update) to Firestore & Local
  async function saveArticle(targetStatus) {
    const title = el.titleInput.value.trim();
    if (!title) {
      alert('Please enter an article headline.');
      el.titleInput.focus();
      return;
    }

    const catId = el.categorySelect.value;
    const catObj = categories.find(c => c.id === catId);
    const catName = catObj ? catObj.name : 'Sports';
    const slug = el.slugInput.value.trim() || generateSlug(title);
    const content = el.contentInput.value.trim();
    const readingTime = calculateReadingTime(content);
    const date = new Date().toISOString().split('T')[0];

    // Parse SEO keywords
    const rawKeywords = el.seoKeywords.value.split(',').map(k => k.trim()).filter(Boolean);
    const seoTitle = el.seoTitle.value.trim() || `${title} | Blog With Sports`;
    const seoMetaDesc = el.seoMetaDesc.value.trim() || el.descriptionInput.value.trim() || title;

    const articleData = {
      title,
      slug,
      categoryId: catId,
      categoryName: catName,
      tags: rawKeywords.length > 0 ? rawKeywords : [catName, 'Sports'],
      description: el.descriptionInput.value.trim() || title,
      content: content || title,
      featuredImage: el.imageInput.value.trim() || IMAGE_PRESETS.football,
      featuredImageCaption: el.captionInput.value.trim(),
      authorId: 'bws-editorial',
      authorName: el.authorInput.value.trim() || 'BWS Editorial',
      authorRole: el.authorRoleInput.value.trim() || 'Senior Desk',
      authorAvatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=160&auto=format&fit=crop&q=80',
      publishedAt: date,
      readingTime: readingTime,
      isTrending: el.trendingCheckbox.checked,
      isFeatured: el.featuredCheckbox.checked,
      status: targetStatus,
      seo: {
        seoTitle: seoTitle,
        metaDescription: seoMetaDesc,
        ogTitle: seoTitle,
        ogDescription: seoMetaDesc,
        ogImage: el.imageInput.value.trim() || IMAGE_PRESETS.football,
        keywords: rawKeywords.length > 0 ? rawKeywords : [catName, 'Sports', 'BWS']
      }
    };

    const docId = editingArticleId || `art-${Date.now()}`;

    // Save directly to Firestore Cloud
    if (db) {
      try {
        await db.collection(ARTICLES_COLLECTION).doc(docId).set({
          id: docId,
          ...articleData,
          views: editingArticleId ? (articles.find(a => a.id === docId)?.views || 0) : 0,
          updatedAt: new Date().toISOString()
        }, { merge: true });

        showToast(targetStatus === 'published' ? 'Published live to Firestore!' : 'Saved draft to Firestore!');
      } catch (err) {
        console.error('Firestore save error:', err);
        showToast('Firestore error: Saved locally', 'warning');
      }
    } else {
      showToast('Saved to local storage (Offline mode)');
    }

    // Local fallback update
    if (editingArticleId) {
      const idx = articles.findIndex(a => a.id === editingArticleId);
      if (idx !== -1) {
        articles[idx] = { ...articles[idx], ...articleData, id: docId };
      }
    } else {
      articles.unshift({ id: docId, views: 0, ...articleData });
    }

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(articles));
      window.dispatchEvent(new Event('storage'));
    } catch {}

    closeModal();
    render();
  }

  // Toggle Publish / Draft in Firestore
  async function toggleStatus(id) {
    const art = articles.find(a => a.id === id);
    if (!art) return;

    const newStatus = art.status === 'published' ? 'draft' : 'published';
    art.status = newStatus;

    if (db) {
      try {
        await db.collection(ARTICLES_COLLECTION).doc(id).update({
          status: newStatus,
          updatedAt: new Date().toISOString()
        });
      } catch (err) {
        console.warn('Firestore toggle status warning:', err);
      }
    }

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(articles));
    } catch {}

    render();
    showToast(`Article set to ${newStatus}`);
  }

  // Delete Article from Firestore & Local
  async function deleteArticle(id) {
    const art = articles.find(a => a.id === id);
    if (!art) return;

    if (!confirm(`Are you sure you want to permanently delete "${art.title}" from Firebase Firestore?`)) {
      return;
    }

    if (db) {
      try {
        await db.collection(ARTICLES_COLLECTION).doc(id).delete();
        showToast('Article deleted from Firestore', 'danger');
      } catch (err) {
        console.error('Firestore delete error:', err);
      }
    }

    articles = articles.filter(a => a.id !== id);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(articles));
    } catch {}

    render();
  }

  // Close Modal
  function closeModal() {
    el.articleModal.classList.remove('active');
    editingArticleId = null;
  }

  // Export articles as JSON file
  function exportJSON() {
    const dataStr = JSON.stringify(articles, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bws-firestore-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(`Exported ${articles.length} articles to JSON file!`);
  }

  // Trigger JSON file input
  function triggerImportJSON() {
    if (el.jsonFileInput) el.jsonFileInput.click();
  }

  // Import JSON file into Firestore
  function handleImportFile(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async function (e) {
      try {
        const imported = JSON.parse(e.target.result);
        if (!Array.isArray(imported)) {
          alert('Invalid format: JSON must be an array of articles.');
          return;
        }

        if (confirm(`Import ${imported.length} articles into Firestore? Existing matching IDs will be synced.`)) {
          if (db) {
            const batch = db.batch();
            imported.forEach(item => {
              if (item.id && item.title) {
                const docRef = db.collection(ARTICLES_COLLECTION).doc(item.id);
                batch.set(docRef, item, { merge: true });
              }
            });
            await batch.commit();
          }

          showToast(`Successfully imported ${imported.length} articles into Firestore!`);
        }
      } catch (err) {
        alert('Error parsing JSON file: ' + err.message);
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  }

  // Set stock image preset
  function setPreset(key) {
    const url = IMAGE_PRESETS[key];
    if (url) {
      el.imageInput.value = url;
      el.imagePreview.src = url;
    }
  }

  // Show Toast
  function showToast(message, type = 'success') {
    if (!el.toastContainer) return;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    el.toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  // Escape HTML
  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Setup Event Listeners
  function setupEventListeners() {
    if (el.titleInput) {
      el.titleInput.addEventListener('input', (e) => {
        if (!editingArticleId) {
          const generatedSlug = generateSlug(e.target.value);
          el.slugInput.value = generatedSlug;
          if (!el.seoTitle.value) {
            el.seoTitle.value = `${e.target.value} | Blog With Sports`;
          }
        }
        updateSEOSnippetPreview();
      });
    }

    if (el.slugInput) {
      el.slugInput.addEventListener('input', updateSEOSnippetPreview);
    }

    if (el.seoTitle) {
      el.seoTitle.addEventListener('input', updateSEOSnippetPreview);
    }

    if (el.seoMetaDesc) {
      el.seoMetaDesc.addEventListener('input', updateSEOSnippetPreview);
    }

    if (el.descriptionInput) {
      el.descriptionInput.addEventListener('input', (e) => {
        if (!el.seoMetaDesc.value) {
          el.seoMetaDesc.value = e.target.value;
        }
        updateSEOSnippetPreview();
      });
    }

    if (el.imageInput) {
      el.imageInput.addEventListener('input', (e) => {
        el.imagePreview.src = e.target.value || IMAGE_PRESETS.football;
      });
    }

    if (el.searchInput) el.searchInput.addEventListener('input', renderArticlesTable);
    if (el.categoryFilter) el.categoryFilter.addEventListener('change', renderArticlesTable);
    if (el.statusFilter) el.statusFilter.addEventListener('change', renderArticlesTable);
    if (el.jsonFileInput) el.jsonFileInput.addEventListener('change', handleImportFile);
  }

  // Global methods
  window.BWSAdmin = {
    openNewModal: openNewArticleModal,
    closeModal: closeModal,
    editArticle: editArticle,
    toggleStatus: toggleStatus,
    deleteArticle: deleteArticle,
    saveArticle: saveArticle,
    exportJSON: exportJSON,
    triggerImport: triggerImportJSON,
    setPreset: setPreset
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
