import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ArticleService } from '@/lib/services/article-service';
import { INITIAL_ARTICLES } from '@/lib/initial-data';
import HomePage from '@/app/page';

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const article = INITIAL_ARTICLES.find(a => a.slug === slug);
  if (!article) {
    return {
      title: 'Article Not Found — Blog With Sports',
    };
  }

  return {
    title: `${article.title} — Blog With Sports (BWS)`,
    description: article.description,
    openGraph: {
      title: article.title,
      description: article.description,
      images: [article.featuredImage],
      type: 'article',
    },
  };
}

export default async function ArticleRoutePage({ params }: Props) {
  const { slug } = await params;
  return <HomePage />;
}
