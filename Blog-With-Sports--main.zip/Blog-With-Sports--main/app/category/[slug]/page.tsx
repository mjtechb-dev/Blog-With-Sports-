import { Metadata } from 'next';
import { INITIAL_CATEGORIES } from '@/lib/initial-data';
import HomePage from '@/app/page';

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const category = INITIAL_CATEGORIES.find(c => c.slug === slug);
  if (!category) {
    return {
      title: 'Category Not Found — Blog With Sports',
    };
  }

  return {
    title: `${category.name} Stories & Analysis — Blog With Sports (BWS)`,
    description: category.description,
  };
}

export default async function CategoryRoutePage({ params }: Props) {
  return <HomePage />;
}
