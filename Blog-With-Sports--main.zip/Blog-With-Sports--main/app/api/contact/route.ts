import { NextRequest, NextResponse } from 'next/server';

const DESTINATION_EMAIL = 'rajonaideveloper@gmail.com';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, email, subject, message } = body;

    if (!name || !email || !message) {
      return NextResponse.json(
        { error: 'Name, email, and message are required fields.' },
        { status: 400 }
      );
    }

    // In a production environment with SMTP/Resend/Sendgrid, send mail to DESTINATION_EMAIL
    // For now, securely log and record dispatch without exposing DESTINATION_EMAIL to the client
    console.log(`[Contact Form] New submission received for: ${DESTINATION_EMAIL}`, {
      fromName: name,
      fromEmail: email,
      subject: subject || 'General Inquiry',
      messagePreview: message.substring(0, 100),
      timestamp: new Date().toISOString(),
    });

    return NextResponse.json({
      success: true,
      message: 'Your message has been securely delivered to the editorial desk.',
    });
  } catch (error) {
    console.error('Contact API Error:', error);
    return NextResponse.json(
      { error: 'An error occurred while transmitting your message.' },
      { status: 500 }
    );
  }
}
