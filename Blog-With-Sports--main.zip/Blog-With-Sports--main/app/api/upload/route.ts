import { NextRequest, NextResponse } from 'next/server';

const DEFAULT_IMGBB_API_KEY = 'b9f93bd32768a501e8f114add1a0a2a3';

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const imageFile = formData.get('image');

    if (!imageFile) {
      return NextResponse.json({ success: false, error: 'No image file provided' }, { status: 400 });
    }

    const apiKey =
      process.env.IMGBB_API_KEY ||
      process.env.NEXT_PUBLIC_IMGBB_API_KEY ||
      DEFAULT_IMGBB_API_KEY;

    const imgbbFormData = new FormData();
    imgbbFormData.append('image', imageFile);

    const imgbbResponse = await fetch(`https://api.imgbb.com/1/upload?key=${apiKey}`, {
      method: 'POST',
      body: imgbbFormData,
    });

    const result = await imgbbResponse.json();

    if (!imgbbResponse.ok || !result.success) {
      return NextResponse.json(
        {
          success: false,
          error: result?.error?.message || 'ImgBB upload failed',
          details: result,
        },
        { status: imgbbResponse.status || 500 }
      );
    }

    // Direct image display URL
    const imageUrl = result.data.url;
    const displayUrl = result.data.display_url || result.data.url;
    const deleteUrl = result.data.delete_url;
    const title = result.data.title || '';

    return NextResponse.json({
      success: true,
      url: imageUrl,
      displayUrl,
      deleteUrl,
      title,
      data: result.data,
    });
  } catch (error: any) {
    console.error('ImgBB API route error:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Internal Server Error' },
      { status: 500 }
    );
  }
}
