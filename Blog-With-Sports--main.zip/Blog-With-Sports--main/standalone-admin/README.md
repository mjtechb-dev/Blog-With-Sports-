# Blog With Sports (BWS) — Standalone Editorial Admin Portal

This is an independent, lightweight administrative suite designed for **Blog With Sports**. It is built strictly with **HTML5, CSS3, and vanilla JavaScript (ES6)** with zero framework dependencies or build steps.

## Highlights & Features

- **Decoupled Architecture**: Completely separate from the Next.js frontend, ensuring zero impact on site performance.
- **Full Article CRUD**:
  - Create and edit sports articles with custom headlines, slugs, category assignments, authors, and cover photos.
  - Quick sports image presets (Football, Basketball, Tennis, F1, Cricket, Baseball).
  - Mark articles as **Homepage Spotlight (Featured)** or **Trending**.
  - Set status to **Draft** or **Published**.
- **Data Portability**:
  - **Export JSON**: One-click download of all articles formatted for backup or database seeding (`bws-articles-YYYY-MM-DD.json`).
  - **Import JSON**: One-click import and restoration of article backups.
- **Instant Browser Sync**:
  - Stores content in browser `localStorage` (`bws_articles_v3`), compatible with the main website. When accessed on the same domain, publishing an article immediately updates the live public site.

## How to Run & Deploy

### Option 1: Run locally on your machine
Simply double-click `index.html` or open it with any web browser (Chrome, Safari, Firefox, Edge). No Node.js or server installation required!

### Option 2: Host on any web hosting service
Upload the folder contents (`index.html`, `styles.css`, `app.js`) to any static host:
- Netlify / Vercel (static)
- GitHub Pages
- Shared hosting (cPanel / Apache / Nginx)
- AWS S3 / Cloudflare Pages

### Option 3: Access via current site
The files are also placed in `/public/admin-portal/` so you can access it directly at `/admin-portal/index.html`.
