'use client';

import React from 'react';

export function ArticleCardSkeleton() {
  return (
    <div className="bg-white border border-neutral-200 rounded-lg overflow-hidden animate-pulse">
      <div className="aspect-[16/10] bg-neutral-200 w-full" />
      <div className="p-4 space-y-3">
        <div className="h-3 bg-neutral-200 rounded w-1/4" />
        <div className="h-5 bg-neutral-200 rounded w-5/6" />
        <div className="h-4 bg-neutral-200 rounded w-full" />
        <div className="pt-3 border-t border-neutral-100 flex justify-between">
          <div className="h-3 bg-neutral-200 rounded w-1/3" />
          <div className="h-3 bg-neutral-200 rounded w-1/4" />
        </div>
      </div>
    </div>
  );
}

export function ArticleDetailSkeleton() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 animate-pulse">
      <div className="h-4 bg-neutral-200 rounded w-24 mb-4" />
      <div className="h-10 bg-neutral-200 rounded w-3/4 mb-4" />
      <div className="h-5 bg-neutral-200 rounded w-1/2 mb-6" />
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-full bg-neutral-200" />
        <div className="space-y-2">
          <div className="h-3 bg-neutral-200 rounded w-28" />
          <div className="h-3 bg-neutral-200 rounded w-40" />
        </div>
      </div>
      <div className="aspect-[16/9] bg-neutral-200 rounded-lg w-full mb-8" />
      <div className="space-y-4 max-w-[70ch] mx-auto">
        <div className="h-4 bg-neutral-200 rounded w-full" />
        <div className="h-4 bg-neutral-200 rounded w-full" />
        <div className="h-4 bg-neutral-200 rounded w-4/5" />
      </div>
    </div>
  );
}
