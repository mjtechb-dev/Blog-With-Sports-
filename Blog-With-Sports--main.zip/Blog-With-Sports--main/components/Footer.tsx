'use client';

import React from 'react';

interface FooterProps {
  onNavigateHome: () => void;
  onNavigateAbout: () => void;
  onNavigateContact: () => void;
  onNavigatePrivacy: () => void;
  onNavigateTerms: () => void;
}

export function Footer({
  onNavigateHome,
  onNavigateAbout,
  onNavigateContact,
  onNavigatePrivacy,
  onNavigateTerms,
}: FooterProps) {
  return (
    <footer className="border-t border-neutral-200 bg-white mt-16 text-neutral-600">
      <div className="max-w-6xl mx-auto px-4 py-10 sm:py-12">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-neutral-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-tight text-lg text-neutral-900">
                Blog With Sports
              </span>
              <span className="bg-neutral-800 text-white font-bold text-[10px] tracking-wider px-1.5 py-0.5 rounded uppercase">
                BWS
              </span>
            </div>
            <p className="text-sm text-neutral-500 mt-1 max-w-md">
              Independent sports stories, analysis and coverage from around the world.
            </p>
          </div>

          <nav className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm font-medium text-neutral-600">
            <button
              onClick={onNavigateHome}
              className="hover:text-neutral-900 transition-colors"
            >
              Home
            </button>
            <button
              onClick={onNavigateAbout}
              className="hover:text-neutral-900 transition-colors"
            >
              About
            </button>
            <button
              onClick={onNavigateContact}
              className="hover:text-neutral-900 transition-colors"
            >
              Contact
            </button>
            <button
              onClick={onNavigatePrivacy}
              className="hover:text-neutral-900 transition-colors"
            >
              Privacy Policy
            </button>
            <button
              onClick={onNavigateTerms}
              className="hover:text-neutral-900 transition-colors"
            >
              Terms
            </button>
          </nav>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-400 gap-3">
          <p>© 2026 Blog With Sports. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
