'use client';

import React from 'react';
import { Newspaper } from 'lucide-react';

interface EmptyStateProps {
  title?: string;
  description?: string;
  actionText?: string;
  onAction?: () => void;
}

export function EmptyState({
  title = 'No sports articles found',
  description = 'There are no stories available in this section currently.',
  actionText,
  onAction,
}: EmptyStateProps) {
  return (
    <div className="py-16 px-4 text-center bg-white border border-neutral-200/90 rounded-xl max-w-md mx-auto my-8">
      <div className="w-12 h-12 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4 text-neutral-400">
        <Newspaper className="w-6 h-6" />
      </div>
      <h3 className="text-base font-bold text-neutral-900 mb-1">{title}</h3>
      <p className="text-xs sm:text-sm text-neutral-500 leading-relaxed max-w-xs mx-auto mb-5">
        {description}
      </p>
      {actionText && onAction && (
        <button
          onClick={onAction}
          className="inline-flex items-center justify-center px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold rounded-md transition-colors shadow-2xs cursor-pointer"
        >
          {actionText}
        </button>
      )}
    </div>
  );
}
