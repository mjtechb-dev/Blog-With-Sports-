'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import {
  LayoutDashboard,
  FileText,
  PlusCircle,
  FolderTree,
  MessageSquare,
  BarChart3,
  Settings,
  LogOut,
  CheckCircle,
  XCircle,
  Trash2,
  Edit,
  Eye,
  Search,
  Upload,
  Globe,
  Share2,
  ArrowLeft,
  Check,
  AlertCircle,
  Loader2,
  Link as LinkIcon,
} from 'lucide-react';
import { Article, Category, Comment, AnalyticsSummary, Author } from '../lib/types';
import { ArticleService } from '../lib/services/article-service';
import { CategoryService } from '../lib/services/category-service';
import { CommentService } from '../lib/services/comment-service';
import { AnalyticsService } from '../lib/services/analytics-service';
import { AuthService, AdminUser } from '../lib/services/auth-service';
import { ImageService, SPORTS_STOCK_PRESETS } from '../lib/services/image-service';
import { INITIAL_AUTHORS, INITIAL_SETTINGS } from '../lib/initial-data';

interface AdminPanelProps {
  onClose: () => void;
  onPreviewArticle: (article: Article) => void;
}

export function AdminPanel({ onClose, onPreviewArticle }: AdminPanelProps) {
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(() => AuthService.getCurrentUser());
  const [emailInput, setEmailInput] = useState('editor@blogwithsports.com');
  const [passwordInput, setPasswordInput] = useState('bws2026');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Tabs: 'dashboard' | 'articles' | 'create' | 'categories' | 'comments' | 'analytics' | 'settings'
  const [activeTab, setActiveTab] = useState<'dashboard' | 'articles' | 'create' | 'categories' | 'comments' | 'analytics' | 'settings'>('dashboard');

  // Data states
  const [articles, setArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Article Editor State (For Create/Edit)
  const [editingArticleId, setEditingArticleId] = useState<string | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formSlug, setFormSlug] = useState('');
  const [formCategory, setFormCategory] = useState('football');
  const [formTags, setFormTags] = useState('Champions League, Tactical Analysis');
  const [formExcerpt, setFormExcerpt] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formImage, setFormImage] = useState('https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=1200&auto=format&fit=crop&q=80');
  const [formImageCaption, setFormImageCaption] = useState('');
  const [formAuthorId, setFormAuthorId] = useState('marcus-vance');
  const [formStatus, setFormStatus] = useState<'draft' | 'published'>('published');
  // SEO fields
  const [seoTitle, setSeoTitle] = useState('');
  const [metaDescription, setMetaDescription] = useState('');
  const [ogTitle, setOgTitle] = useState('');
  const [ogDescription, setOgDescription] = useState('');
  const [isUploadingImage, setIsUploadingImage] = useState(false);

  // Category Form State
  const [newCatName, setNewCatName] = useState('');
  const [newCatSlug, setNewCatSlug] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const loadAllData = React.useCallback(async () => {
    setLoading(true);
    try {
      const [allArticles, allCats, allComms, stats] = await Promise.all([
        ArticleService.getAll({ status: 'all' }),
        CategoryService.getAll(false),
        CommentService.getAll('all'),
        AnalyticsService.getSummary(),
      ]);
      setArticles(allArticles);
      setCategories(allCats);
      setComments(allComms);
      setAnalytics(stats);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch data if user is authenticated
  useEffect(() => {
    if (!currentUser) return;
    let isMounted = true;
    Promise.all([
      ArticleService.getAll({ status: 'all' }),
      CategoryService.getAll(false),
      CommentService.getAll('all'),
      AnalyticsService.getSummary(),
    ]).then(([allArticles, allCats, allComms, stats]) => {
      if (!isMounted) return;
      setArticles(allArticles);
      setCategories(allCats);
      setComments(allComms);
      setAnalytics(stats);
    }).catch(err => {
      console.error('Failed to load admin data:', err);
    });

    return () => {
      isMounted = false;
    };
  }, [currentUser]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    try {
      const user = await AuthService.login(emailInput, passwordInput);
      setCurrentUser(user);
      loadAllData();
      showToast('Logged in to BWS Editorial Desk');
    } catch (err: any) {
      setLoginError(err.message || 'Login failed');
    }
  };

  const handleLogout = () => {
    AuthService.logout();
    setCurrentUser(null);
  };

  // Helper to auto-generate slug
  const handleTitleChange = (val: string) => {
    setFormTitle(val);
    if (!editingArticleId) {
      const generated = val
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .trim()
        .replace(/\s+/g, '-');
      setFormSlug(generated);
      if (!seoTitle) setSeoTitle(val ? `${val} | BWS` : '');
    }
  };

  const handleStartCreate = () => {
    setEditingArticleId(null);
    setFormTitle('');
    setFormSlug('');
    setFormCategory(categories[0]?.id || 'football');
    setFormTags('Sports, Analysis');
    setFormExcerpt('');
    setFormContent(`## Match Overview

Detailed tactical breakdown and analysis of the match.

### Key Tactical Moments

* **First Half Phase:** Key observations and team positioning.
* **Turning Point:** Decisive substitutions and tactical reorganizations.

> "Quote from the manager or key performer summarizing the outcome."

### Looking Ahead

What this result means for upcoming fixtures and standings.`);
    setFormImage(SPORTS_STOCK_PRESETS[0].url);
    setFormImageCaption('Match action under the stadium floodlights.');
    setFormAuthorId(INITIAL_AUTHORS[0]?.id || 'marcus-vance');
    setFormStatus('published');
    setSeoTitle('');
    setMetaDescription('');
    setOgTitle('');
    setOgDescription('');
    setActiveTab('create');
  };

  const handleStartEdit = (art: Article) => {
    setEditingArticleId(art.id);
    setFormTitle(art.title);
    setFormSlug(art.slug);
    setFormCategory(art.categoryId);
    setFormTags(art.tags.join(', '));
    setFormExcerpt(art.description);
    setFormContent(art.content);
    setFormImage(art.featuredImage);
    setFormImageCaption(art.featuredImageCaption || '');
    setFormAuthorId(art.authorId);
    setFormStatus(art.status);
    setSeoTitle(art.seo?.seoTitle || art.title);
    setMetaDescription(art.seo?.metaDescription || art.description);
    setOgTitle(art.seo?.ogTitle || art.title);
    setOgDescription(art.seo?.ogDescription || art.description);
    setActiveTab('create');
  };

  const handleSaveArticle = async (asDraft = false) => {
    if (!formTitle.trim()) {
      alert('Please enter an article title');
      return;
    }

    const selectedCatObj = categories.find(c => c.id === formCategory) || categories[0];
    const selectedAuthor = INITIAL_AUTHORS.find(a => a.id === formAuthorId) || INITIAL_AUTHORS[0];
    const cleanTags = formTags.split(',').map(t => t.trim()).filter(Boolean);

    const articlePayload = {
      title: formTitle.trim(),
      slug: formSlug.trim() || formTitle.toLowerCase().replace(/\s+/g, '-'),
      categoryId: selectedCatObj.id,
      categoryName: selectedCatObj.name,
      tags: cleanTags,
      description: formExcerpt.trim() || formTitle,
      content: formContent.trim(),
      featuredImage: formImage,
      featuredImageCaption: formImageCaption.trim(),
      authorId: selectedAuthor.id,
      authorName: selectedAuthor.name,
      authorRole: selectedAuthor.role,
      authorAvatar: selectedAuthor.avatar,
      publishedAt: new Date().toISOString().split('T')[0],
      status: (asDraft ? 'draft' : formStatus) as 'draft' | 'published',
      readingTime: `${Math.max(3, Math.ceil(formContent.split(/\s+/).length / 180))} min read`,
      seo: {
        seoTitle: seoTitle.trim() || `${formTitle} | BWS`,
        metaDescription: metaDescription.trim() || formExcerpt,
        ogTitle: ogTitle.trim() || formTitle,
        ogDescription: ogDescription.trim() || formExcerpt,
        ogImage: formImage,
        keywords: cleanTags,
      },
    };

    try {
      if (editingArticleId) {
        await ArticleService.update(editingArticleId, articlePayload);
        showToast('Article updated successfully');
      } else {
        await ArticleService.create(articlePayload);
        showToast('Article created and saved');
      }
      await loadAllData();
      setActiveTab('articles');
    } catch (err: any) {
      alert(err.message || 'Failed to save article');
    }
  };

  const handleDeleteArticle = async (id: string) => {
    if (!confirm('Are you sure you want to delete this article?')) return;
    await ArticleService.delete(id);
    showToast('Article deleted');
    loadAllData();
  };

  const handleTogglePublish = async (art: Article) => {
    const nextStatus = art.status === 'published' ? 'draft' : 'published';
    await ArticleService.update(art.id, { status: nextStatus });
    showToast(`Article marked as ${nextStatus}`);
    loadAllData();
  };

  // Image Upload handler for ImgBB
  const handleImageFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploadingImage(true);
    try {
      showToast('Uploading image to ImgBB API...');
      const result = await ImageService.upload(file);
      setFormImage(result.url);
      if (!formImageCaption) {
        setFormImageCaption(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '));
      }
      showToast(
        result.source === 'imgbb'
          ? 'Image uploaded to ImgBB & direct link set!'
          : 'Image processed and attached'
      );
    } catch (err: any) {
      alert('Failed to upload image: ' + (err.message || err));
    } finally {
      setIsUploadingImage(false);
      // reset file input so the same file can be chosen again if needed
      e.target.value = '';
    }
  };

  // Comment Moderation
  const handleApproveComment = async (id: string) => {
    await CommentService.updateStatus(id, 'approved');
    showToast('Comment approved for publication');
    loadAllData();
  };

  const handleDeleteComment = async (id: string) => {
    await CommentService.delete(id);
    showToast('Comment removed');
    loadAllData();
  };

  // Category Add
  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    const slug = newCatSlug.trim() || newCatName.toLowerCase().replace(/\s+/g, '-');
    await CategoryService.create({
      name: newCatName.trim(),
      slug,
      description: newCatDesc.trim() || `${newCatName} sports journalism and stories.`,
      status: 'active',
      order: categories.length + 1,
    });
    setNewCatName('');
    setNewCatSlug('');
    setNewCatDesc('');
    showToast('Category created');
    loadAllData();
  };

  // Login view if not authenticated
  if (!currentUser) {
    return (
      <div className="fixed inset-0 z-50 bg-neutral-900/60 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl border border-neutral-200 w-full max-w-md overflow-hidden animate-in fade-in">
          <div className="p-6 border-b border-neutral-100 bg-[#FBFBFA] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-lg text-neutral-900">BWS Admin</span>
              <span className="bg-emerald-800 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                Editorial Access
              </span>
            </div>
            <button
              onClick={onClose}
              className="text-neutral-400 hover:text-neutral-700 p-1 rounded hover:bg-neutral-100 text-xs font-semibold"
            >
              Close
            </button>
          </div>

          <form onSubmit={handleLogin} className="p-6 space-y-4">
            <p className="text-xs text-neutral-500">
              Sign in to manage sports articles, categories, comments moderation, SEO, and reader views.
            </p>

            {loginError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-md">
                {loginError}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                Admin Email
              </label>
              <input
                type="email"
                value={emailInput}
                onChange={e => setEmailInput(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                Password
              </label>
              <input
                type="password"
                value={passwordInput}
                onChange={e => setPasswordInput(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
              />
              <p className="text-[11px] text-neutral-400 mt-1">
                Demo credentials pre-filled: <span className="font-mono text-neutral-600">editor@blogwithsports.com / bws2026</span>
              </p>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-md"
              >
                Back to Site
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors"
              >
                Sign In
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-neutral-900/50 backdrop-blur-xs flex flex-col md:flex-row overflow-hidden animate-in fade-in">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-neutral-900 text-white text-xs px-4 py-2.5 rounded-lg shadow-lg border border-neutral-700 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Admin Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-white border-b md:border-b-0 md:border-r border-neutral-200 flex flex-col shrink-0">
        {/* Sidebar Header */}
        <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base text-neutral-900">BWS Admin</span>
              <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded uppercase">
                Desk
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 truncate max-w-[170px]">{currentUser.email}</p>
          </div>
          <button
            onClick={onClose}
            className="md:hidden p-1.5 text-neutral-500 hover:bg-neutral-100 rounded-md"
          >
            <XCircle className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <nav className="p-3 space-y-1 flex-1 overflow-y-auto">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'dashboard'
                ? 'bg-emerald-50 text-emerald-900 font-bold'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 text-neutral-500" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('articles')}
            className={`w-full flex items-center justify-between px-3 py-2 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'articles'
                ? 'bg-emerald-50 text-emerald-900 font-bold'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <FileText className="w-4 h-4 text-neutral-500" />
              <span>Articles</span>
            </div>
            <span className="bg-neutral-100 text-neutral-600 text-[10px] font-bold px-1.5 py-0.5 rounded-full">
              {articles.length}
            </span>
          </button>

          <button
            onClick={handleStartCreate}
            className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'create'
                ? 'bg-emerald-800 text-white'
                : 'text-emerald-800 hover:bg-emerald-50'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Write New Article</span>
          </button>

          <button
            onClick={() => setActiveTab('categories')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'categories'
                ? 'bg-emerald-50 text-emerald-900 font-bold'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <FolderTree className="w-4 h-4 text-neutral-500" />
            <span>Categories</span>
          </button>

          <button
            onClick={() => setActiveTab('comments')}
            className={`w-full flex items-center justify-between px-3 py-2 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'comments'
                ? 'bg-emerald-50 text-emerald-900 font-bold'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <MessageSquare className="w-4 h-4 text-neutral-500" />
              <span>Comments</span>
            </div>
            {comments.filter(c => c.status === 'pending').length > 0 && (
              <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                {comments.filter(c => c.status === 'pending').length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'analytics'
                ? 'bg-emerald-50 text-emerald-900 font-bold'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-neutral-500" />
            <span>Visitor Statistics</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'settings'
                ? 'bg-emerald-50 text-emerald-900 font-bold'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            <Settings className="w-4 h-4 text-neutral-500" />
            <span>SEO & Settings</span>
          </button>
        </nav>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-neutral-200 bg-[#FBFBFA] flex items-center justify-between">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 text-xs text-neutral-600 hover:text-neutral-900 font-medium"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Site</span>
          </button>

          <button
            onClick={handleLogout}
            className="p-1.5 text-neutral-400 hover:text-red-600 rounded transition-colors"
            title="Sign out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Admin Content Canvas */}
      <main className="flex-1 bg-[#FAF9F5] overflow-y-auto p-4 sm:p-6 lg:p-8">
        {/* TAB 1: DASHBOARD */}
        {activeTab === 'dashboard' && analytics && (
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-neutral-200">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
                  Editorial Dashboard
                </h2>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Real-time international audience metrics, article inventory, and reader comments.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleStartCreate}
                  className="px-3.5 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs flex items-center gap-1.5"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>Publish Story</span>
                </button>
              </div>
            </div>

            {/* Metrics Overview Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-xl border border-neutral-200/90 shadow-2xs">
                <p className="text-xs text-neutral-500 font-medium">Today&apos;s Readers</p>
                <p className="text-2xl font-extrabold text-neutral-900 mt-1">
                  {analytics.todayVisitors.toLocaleString()}
                </p>
                <p className="text-[11px] text-emerald-700 font-semibold mt-1">
                  +14% vs yesterday
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-neutral-200/90 shadow-2xs">
                <p className="text-xs text-neutral-500 font-medium">Total Article Views</p>
                <p className="text-2xl font-extrabold text-neutral-900 mt-1">
                  {analytics.totalArticleViews.toLocaleString()}
                </p>
                <p className="text-[11px] text-neutral-400 mt-1">
                  Across {analytics.publishedArticlesCount} published stories
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-neutral-200/90 shadow-2xs">
                <p className="text-xs text-neutral-500 font-medium">Published Stories</p>
                <p className="text-2xl font-extrabold text-neutral-900 mt-1">
                  {analytics.publishedArticlesCount}
                </p>
                <p className="text-[11px] text-neutral-400 mt-1">
                  {analytics.totalArticlesCount - analytics.publishedArticlesCount} drafts pending
                </p>
              </div>

              <div className="bg-white p-4 rounded-xl border border-neutral-200/90 shadow-2xs">
                <p className="text-xs text-neutral-500 font-medium">Comments Awaiting Review</p>
                <p className="text-2xl font-extrabold text-amber-700 mt-1">
                  {analytics.pendingCommentsCount}
                </p>
                <button
                  onClick={() => setActiveTab('comments')}
                  className="text-[11px] text-neutral-600 hover:text-emerald-800 font-semibold mt-1 underline block text-left"
                >
                  Review comments
                </button>
              </div>
            </div>

            {/* Most Read Articles Table */}
            <div className="bg-white rounded-xl border border-neutral-200/90 p-5">
              <h3 className="text-sm font-bold text-neutral-900 mb-3">
                Most Read Articles This Week
              </h3>
              <div className="divide-y divide-neutral-100">
                {articles
                  .filter(a => a.status === 'published')
                  .sort((a, b) => b.views - a.views)
                  .slice(0, 5)
                  .map((art, idx) => (
                    <div key={art.id} className="py-2.5 flex items-center justify-between text-xs gap-4">
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="font-mono font-bold text-neutral-400 w-4">
                          0{idx + 1}
                        </span>
                        <div className="min-w-0">
                          <p className="font-semibold text-neutral-800 truncate">{art.title}</p>
                          <p className="text-[11px] text-neutral-400">{art.categoryName} · By {art.authorName}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <span className="font-semibold text-neutral-700">
                          {art.views.toLocaleString()} views
                        </span>
                        <button
                          onClick={() => onPreviewArticle(art)}
                          className="text-emerald-800 hover:underline text-[11px] font-semibold"
                        >
                          View
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: ARTICLES LIST */}
        {activeTab === 'articles' && (
          <div className="max-w-5xl mx-auto space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-200">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
                  Article Management
                </h2>
                <p className="text-xs text-neutral-500">
                  Manage published journalism, drafts, view counts, and editorial metadata.
                </p>
              </div>
              <button
                onClick={handleStartCreate}
                className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs flex items-center gap-1.5 self-start"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Write New Article</span>
              </button>
            </div>

            <div className="bg-white rounded-xl border border-neutral-200/90 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-neutral-700">
                  <thead className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-200 uppercase tracking-wider text-[10px]">
                    <tr>
                      <th className="py-3 px-4">Article</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4">Author</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Views</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {articles.map(art => (
                      <tr key={art.id} className="hover:bg-neutral-50/70 transition-colors">
                        <td className="py-3 px-4 max-w-xs">
                          <p className="font-bold text-neutral-900 line-clamp-1">{art.title}</p>
                          <p className="text-[11px] text-neutral-400 line-clamp-1 mt-0.5">{art.slug}</p>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className="font-medium text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded text-[11px]">
                            {art.categoryName}
                          </span>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">{art.authorName}</td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <button
                            onClick={() => handleTogglePublish(art)}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              art.status === 'published'
                                ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                : 'bg-neutral-200 text-neutral-700 hover:bg-neutral-300'
                            }`}
                            title="Click to toggle status"
                          >
                            {art.status}
                          </button>
                        </td>
                        <td className="py-3 px-4 font-mono whitespace-nowrap">
                          {art.views.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                          <button
                            onClick={() => onPreviewArticle(art)}
                            className="p-1 hover:text-emerald-800 text-neutral-500 rounded"
                            title="Preview Public Page"
                          >
                            <Eye className="w-4 h-4 inline" />
                          </button>
                          <button
                            onClick={() => handleStartEdit(art)}
                            className="p-1 hover:text-neutral-900 text-neutral-500 rounded"
                            title="Edit Article"
                          >
                            <Edit className="w-4 h-4 inline" />
                          </button>
                          <button
                            onClick={() => handleDeleteArticle(art.id)}
                            className="p-1 hover:text-red-600 text-neutral-400 rounded"
                            title="Delete Article"
                          >
                            <Trash2 className="w-4 h-4 inline" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CREATE / EDIT ARTICLE */}
        {activeTab === 'create' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('articles')}
                  className="p-1 hover:bg-neutral-100 rounded text-neutral-500"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <h2 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
                  {editingArticleId ? 'Edit Article' : 'Compose Sports Article'}
                </h2>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleSaveArticle(true)}
                  className="px-3 py-1.5 border border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-700 text-xs font-semibold rounded-md shadow-2xs"
                >
                  Save Draft
                </button>
                <button
                  onClick={() => handleSaveArticle(false)}
                  className="px-4 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs"
                >
                  Publish Article
                </button>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-neutral-200/90 p-6 space-y-6 shadow-2xs">
              {/* Title & Slug */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                    Article Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formTitle}
                    onChange={e => handleTitleChange(e.target.value)}
                    placeholder="e.g. Real Madrid Edge Inter in Dramatic Champions League Clash"
                    className="w-full text-lg sm:text-xl font-bold px-3.5 py-2.5 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-800"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 mb-1">
                      URL Slug
                    </label>
                    <input
                      type="text"
                      value={formSlug}
                      onChange={e => setFormSlug(e.target.value)}
                      placeholder="e.g. real-madrid-edge-inter"
                      className="w-full text-xs font-mono px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 mb-1">
                      Sports Category
                    </label>
                    <select
                      value={formCategory}
                      onChange={e => setFormCategory(e.target.value)}
                      className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800 bg-white"
                    >
                      {categories.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Author & Tags */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-600 mb-1">
                    Author
                  </label>
                  <select
                    value={formAuthorId}
                    onChange={e => setFormAuthorId(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800 bg-white"
                  >
                    {INITIAL_AUTHORS.map(a => (
                      <option key={a.id} value={a.id}>
                        {a.name} ({a.role})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-600 mb-1">
                    Tags (comma separated)
                  </label>
                  <input
                    type="text"
                    value={formTags}
                    onChange={e => setFormTags(e.target.value)}
                    placeholder="Champions League, Real Madrid, Tactical Analysis"
                    className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                  />
                </div>
              </div>

              {/* Short description / Excerpt */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700 mb-1">
                  Short Excerpt / Subtitle
                </label>
                <textarea
                  rows={2}
                  value={formExcerpt}
                  onChange={e => setFormExcerpt(e.target.value)}
                  placeholder="A concise two-line summary of the match or tactical narrative..."
                  className="w-full text-xs sm:text-sm px-3.5 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                />
              </div>

              {/* Featured Image Selector & ImgBB upload */}
              <div className="space-y-3 pt-2 border-t border-neutral-100">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700">
                    Featured Image
                  </label>
                  <span className="text-[11px] font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                    ImgBB Cloud Hosting
                  </span>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 items-start">
                  <div className="relative w-full sm:w-56 aspect-[16/10] rounded-lg overflow-hidden bg-neutral-100 border border-neutral-200 shrink-0">
                    {formImage ? (
                      <Image
                        src={formImage}
                        alt="Preview"
                        fill
                        sizes="224px"
                        className="object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full text-xs text-neutral-400">
                        No image selected
                      </div>
                    )}
                    {isUploadingImage && (
                      <div className="absolute inset-0 bg-neutral-900/60 flex flex-col items-center justify-center gap-1 text-white text-xs font-semibold">
                        <Loader2 className="w-5 h-5 animate-spin text-emerald-400" />
                        <span>Uploading to ImgBB...</span>
                      </div>
                    )}
                  </div>

                  <div className="flex-1 space-y-2.5 w-full">
                    <div className="relative">
                      <input
                        type="url"
                        value={formImage}
                        onChange={e => setFormImage(e.target.value)}
                        placeholder="Image Direct URL (Auto-filled on ImgBB upload)"
                        className="w-full text-xs font-mono pr-8 px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800 bg-neutral-50/50"
                      />
                      {formImage && formImage.includes('ibb.co') && (
                        <span className="absolute right-2 top-2 text-[10px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">
                          ImgBB
                        </span>
                      )}
                    </div>

                    <input
                      type="text"
                      value={formImageCaption}
                      onChange={e => setFormImageCaption(e.target.value)}
                      placeholder="Image caption (e.g. Santiago Bernabéu under floodlights)"
                      className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                    />

                    {/* Upload button & Stock presets */}
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <label
                        className={`cursor-pointer inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-md shadow-xs transition-all ${
                          isUploadingImage
                            ? 'bg-neutral-200 text-neutral-500 cursor-not-allowed'
                            : 'bg-emerald-800 hover:bg-emerald-900 text-white'
                        }`}
                      >
                        {isUploadingImage ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            <span>Uploading to ImgBB...</span>
                          </>
                        ) : (
                          <>
                            <Upload className="w-3.5 h-3.5" />
                            <span>Upload Image (via ImgBB API)</span>
                          </>
                        )}
                        <input
                          type="file"
                          accept="image/*"
                          disabled={isUploadingImage}
                          onChange={handleImageFile}
                          className="hidden"
                        />
                      </label>

                      <span className="text-xs text-neutral-400">or presets:</span>

                      {SPORTS_STOCK_PRESETS.slice(0, 4).map(preset => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => {
                            setFormImage(preset.url);
                            setFormImageCaption(preset.caption);
                          }}
                          className="text-[11px] px-2 py-1 bg-neutral-100 hover:bg-emerald-100 text-neutral-700 hover:text-emerald-900 rounded transition-colors"
                        >
                          {preset.category}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Rich Content Editor */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-700">
                    Article Body Content (Markdown Supported)
                  </label>
                  <span className="text-[11px] text-neutral-400">
                    Supports ## H2, ### H3, **bold**, &gt; quotes, * lists, and match tables
                  </span>
                </div>
                <textarea
                  rows={14}
                  value={formContent}
                  onChange={e => setFormContent(e.target.value)}
                  placeholder="Compose full long-form sports article..."
                  className="w-full font-mono text-xs sm:text-sm px-4 py-3 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800 leading-relaxed"
                />
              </div>

              {/* SEO SETTINGS & PREVIEW (PRD Section 30 & 40) */}
              <div className="pt-6 border-t border-neutral-200 space-y-4">
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-emerald-800" />
                  <h3 className="text-sm font-bold text-neutral-900">
                    SEO & Social Graph Controls
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 mb-1">
                      SEO Meta Title
                    </label>
                    <input
                      type="text"
                      value={seoTitle}
                      onChange={e => setSeoTitle(e.target.value)}
                      placeholder="Title displayed in Google search"
                      className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-600 mb-1">
                      SEO Meta Description
                    </label>
                    <input
                      type="text"
                      value={metaDescription}
                      onChange={e => setMetaDescription(e.target.value)}
                      placeholder="150-160 characters summary for search engines"
                      className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                    />
                  </div>
                </div>

                {/* Google Search Live Preview */}
                <div className="bg-[#F8F9FA] p-4 rounded-lg border border-neutral-200">
                  <p className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 mb-2">
                    Google Search Engine Snippet Preview
                  </p>
                  <div className="font-sans text-xs">
                    <p className="text-[11px] text-emerald-800">
                      https://blogwithsports.pages.dev/article/{formSlug || 'article-slug'}
                    </p>
                    <p className="text-base text-blue-800 hover:underline font-medium leading-tight mt-0.5">
                      {seoTitle || formTitle || 'Article Title — Blog With Sports (BWS)'}
                    </p>
                    <p className="text-neutral-600 text-xs mt-1 leading-relaxed line-clamp-2">
                      {metaDescription || formExcerpt || 'Independent sports stories, tactical analysis and international coverage.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="pt-4 border-t border-neutral-200 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setActiveTab('articles')}
                  className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-md"
                >
                  Cancel
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleSaveArticle(true)}
                    className="px-4 py-2 border border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-700 text-xs font-semibold rounded-md shadow-2xs"
                  >
                    Save as Draft
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSaveArticle(false)}
                    className="px-5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors"
                  >
                    Publish Article
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: CATEGORIES */}
        {activeTab === 'categories' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="pb-4 border-b border-neutral-200">
              <h2 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
                Sports Categories
              </h2>
              <p className="text-xs text-neutral-500">
                Organize sports beats, manage navigation ordering, and configure coverage topics.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Existing Categories List */}
              <div className="md:col-span-7 bg-white rounded-xl border border-neutral-200/90 overflow-hidden">
                <div className="p-4 border-b border-neutral-100 font-bold text-xs text-neutral-900 uppercase tracking-wider">
                  Active Categories ({categories.length})
                </div>
                <div className="divide-y divide-neutral-100">
                  {categories.map(cat => (
                    <div key={cat.id} className="p-4 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-neutral-900 text-sm">{cat.name}</span>
                        <p className="text-neutral-500 text-[11px] mt-0.5">{cat.description}</p>
                        <span className="font-mono text-neutral-400 text-[10px]">/category/{cat.slug}</span>
                      </div>
                      <span className="bg-emerald-50 text-emerald-800 font-semibold px-2 py-0.5 rounded text-[10px] uppercase">
                        {cat.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add Category Form */}
              <div className="md:col-span-5 bg-white rounded-xl border border-neutral-200/90 p-5 space-y-4">
                <h3 className="text-sm font-bold text-neutral-900">
                  Add New Sports Category
                </h3>

                <form onSubmit={handleAddCategory} className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Category Name
                    </label>
                    <input
                      type="text"
                      value={newCatName}
                      onChange={e => {
                        setNewCatName(e.target.value);
                        if (!newCatSlug) {
                          setNewCatSlug(e.target.value.toLowerCase().replace(/\s+/g, '-'));
                        }
                      }}
                      placeholder="e.g. Rugby"
                      required
                      className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      URL Slug
                    </label>
                    <input
                      type="text"
                      value={newCatSlug}
                      onChange={e => setNewCatSlug(e.target.value)}
                      placeholder="e.g. rugby"
                      className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">
                      Description
                    </label>
                    <textarea
                      rows={3}
                      value={newCatDesc}
                      onChange={e => setNewCatDesc(e.target.value)}
                      placeholder="Coverage overview for this sport..."
                      className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors"
                  >
                    Add Category
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: COMMENTS MODERATION (PRD Section 17 & 39) */}
        {activeTab === 'comments' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="pb-4 border-b border-neutral-200">
              <h2 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
                Comments Moderation
              </h2>
              <p className="text-xs text-neutral-500">
                Review visitor comments submitted via email verification before they are published.
              </p>
            </div>

            <div className="bg-white rounded-xl border border-neutral-200/90 divide-y divide-neutral-100 overflow-hidden">
              {comments.length === 0 ? (
                <div className="p-8 text-center text-neutral-500 text-xs">
                  No comments logged in the database yet.
                </div>
              ) : (
                comments.map(c => (
                  <div key={c.id} className="p-4 sm:p-5 flex flex-col sm:flex-row items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-bold text-sm text-neutral-900">{c.name}</span>
                        <span className="text-xs text-neutral-400">({c.email})</span>
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                            c.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {c.status}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-neutral-700 leading-relaxed mt-1">
                        {c.comment}
                      </p>
                      <p className="text-[11px] text-neutral-400 mt-2">
                        Submitted on {new Date(c.createdAt).toLocaleDateString()}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {c.status !== 'approved' && (
                        <button
                          onClick={() => handleApproveComment(c.id)}
                          className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-semibold rounded-md shadow-2xs flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Approve</span>
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteComment(c.id)}
                        className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-md"
                        title="Delete Comment"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 6: VISITOR STATISTICS (PRD Section 16 & 36) */}
        {activeTab === 'analytics' && analytics && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="pb-4 border-b border-neutral-200">
              <h2 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
                Visitor & Reading Analytics
              </h2>
              <p className="text-xs text-neutral-500">
                Lightweight anonymous visitor telemetry and article engagement counts.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white p-5 rounded-xl border border-neutral-200">
                <p className="text-xs font-semibold text-neutral-500">Total Page Views</p>
                <p className="text-3xl font-extrabold text-neutral-900 mt-1">
                  {analytics.todayPageViews.toLocaleString()}
                </p>
                <p className="text-xs text-neutral-400 mt-1">Recorded today</p>
              </div>

              <div className="bg-white p-5 rounded-xl border border-neutral-200">
                <p className="text-xs font-semibold text-neutral-500">Unique Daily Visitors</p>
                <p className="text-3xl font-extrabold text-neutral-900 mt-1">
                  {analytics.todayVisitors.toLocaleString()}
                </p>
                <p className="text-xs text-emerald-700 font-semibold mt-1">USA, UK & UAE primary</p>
              </div>

              <div className="bg-white p-5 rounded-xl border border-neutral-200">
                <p className="text-xs font-semibold text-neutral-500">Total Article Reads</p>
                <p className="text-3xl font-extrabold text-neutral-900 mt-1">
                  {analytics.totalArticleViews.toLocaleString()}
                </p>
                <p className="text-xs text-neutral-400 mt-1">Cumulative views</p>
              </div>
            </div>

            {/* Traffic History Trend Table */}
            <div className="bg-white p-5 rounded-xl border border-neutral-200">
              <h3 className="text-sm font-bold text-neutral-900 mb-4">
                7-Day Traffic Trajectory
              </h3>
              <div className="space-y-3">
                {analytics.recentTraffic.map(day => (
                  <div key={day.date} className="flex items-center text-xs gap-4">
                    <span className="w-16 font-semibold text-neutral-600">{day.date}</span>
                    <div className="flex-1 bg-neutral-100 rounded-full h-3.5 overflow-hidden">
                      <div
                        className="bg-emerald-800 h-full rounded-full transition-all duration-500"
                        style={{ width: `${Math.min(100, (day.views / 8000) * 100)}%` }}
                      />
                    </div>
                    <span className="font-mono font-semibold text-neutral-800 w-24 text-right">
                      {day.views.toLocaleString()} views
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 7: SETTINGS & SEO (PRD Section 30 & 53) */}
        {activeTab === 'settings' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="pb-4 border-b border-neutral-200">
              <h2 className="text-xl sm:text-2xl font-extrabold text-neutral-900">
                Site Identity & Default SEO
              </h2>
              <p className="text-xs text-neutral-500">
                Global publication configuration for Blog With Sports (BWS).
              </p>
            </div>

            <div className="bg-white rounded-xl border border-neutral-200/90 p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Publication Name
                </label>
                <input
                  type="text"
                  defaultValue={INITIAL_SETTINGS.siteName}
                  className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Tagline
                </label>
                <input
                  type="text"
                  defaultValue={INITIAL_SETTINGS.siteTagline}
                  className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Editorial Desk Location
                </label>
                <input
                  type="text"
                  defaultValue={INITIAL_SETTINGS.editorialDeskLocation}
                  className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  Default Meta Description
                </label>
                <textarea
                  rows={2}
                  defaultValue={INITIAL_SETTINGS.defaultMetaDescription}
                  className="w-full text-xs px-3 py-2 border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800"
                />
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => showToast('Settings updated')}
                  className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md shadow-xs transition-colors"
                >
                  Save Settings
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
