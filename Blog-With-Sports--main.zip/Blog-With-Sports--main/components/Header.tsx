'use client';

import React, { useState } from 'react';
import { Search, Menu, X, ArrowUpRight } from 'lucide-react';
import { Category } from '../lib/types';

interface HeaderProps {
  categories: Category[];
  currentCategory?: string;
  activeView: string;
  onNavigateHome: () => void;
  onSelectCategory: (slug: string) => void;
  onOpenSearch: () => void;
  onNavigateAbout: () => void;
  onNavigateContact: () => void;
}

export function Header({
  categories,
  currentCategory,
  activeView,
  onNavigateHome,
  onSelectCategory,
  onOpenSearch,
  onNavigateAbout,
  onNavigateContact,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Top prominent categories for header
  const primaryCategories = categories.slice(0, 5);
  const remainingCategories = categories.slice(5);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-neutral-200">
      {/* Main compact header bar */}
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
        {/* Left: Brand / Logo */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => {
              onNavigateHome();
              setMobileMenuOpen(false);
            }}
            className="text-left group focus:outline-none"
          >
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-tight text-xl sm:text-2xl text-neutral-900 group-hover:text-emerald-800 transition-colors">
                Blog With Sports
              </span>
              <span className="bg-emerald-800 text-white font-bold text-[11px] tracking-wider px-1.5 py-0.5 rounded uppercase">
                BWS
              </span>
            </div>
            <p className="text-[11px] text-neutral-500 hidden sm:block tracking-wide">
              Independent Sports Journalism & Analysis
            </p>
          </button>
        </div>

        {/* Center: Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1 text-sm font-medium text-neutral-700">
          <button
            onClick={() => {
              onNavigateHome();
            }}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeView === 'home' && !currentCategory
                ? 'bg-neutral-100 text-emerald-800 font-semibold'
                : 'hover:text-neutral-950 hover:bg-neutral-50'
            }`}
          >
            Home
          </button>

          {primaryCategories.map(cat => {
            const isSelected = activeView === 'category' && currentCategory === cat.slug;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.slug)}
                className={`px-3 py-1.5 rounded-md transition-colors ${
                  isSelected
                    ? 'bg-emerald-50 text-emerald-800 font-semibold'
                    : 'hover:text-neutral-950 hover:bg-neutral-50'
                }`}
              >
                {cat.name}
              </button>
            );
          })}

          {/* More dropdown / additional categories */}
          {remainingCategories.length > 0 && (
            <div className="relative group">
              <button className="px-3 py-1.5 rounded-md hover:text-neutral-950 hover:bg-neutral-50 flex items-center gap-1 transition-colors">
                More
              </button>
              <div className="absolute right-0 top-full pt-1 hidden group-hover:block w-48 shadow-lg bg-white border border-neutral-200 rounded-md py-1 z-50">
                {remainingCategories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => onSelectCategory(cat.slug)}
                    className="w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-50 hover:text-emerald-800 flex items-center justify-between"
                  >
                    <span>{cat.name}</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-neutral-400" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </nav>

        {/* Right: Search & Mobile Menu Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSearch}
            className="p-2 text-neutral-600 hover:text-neutral-950 hover:bg-neutral-100 rounded-md transition-colors flex items-center gap-1.5 text-sm"
            aria-label="Search articles"
          >
            <Search className="w-4 h-4" />
            <span className="hidden lg:inline text-xs text-neutral-400">Search...</span>
          </button>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-neutral-700 hover:text-neutral-950 hover:bg-neutral-100 rounded-md transition-colors"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer / Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-neutral-200 bg-white px-4 py-3 shadow-md animate-in fade-in duration-150">
          <div className="flex flex-col space-y-1 pb-3 border-b border-neutral-100">
            <button
              onClick={() => {
                onNavigateHome();
                setMobileMenuOpen(false);
              }}
              className={`text-left px-3 py-2 rounded-md font-medium text-sm ${
                activeView === 'home' && !currentCategory
                  ? 'bg-neutral-100 text-emerald-800 font-semibold'
                  : 'text-neutral-700 hover:bg-neutral-50'
              }`}
            >
              Home
            </button>

            <div className="pt-2 pb-1 px-3 text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
              Sports Categories
            </div>

            <div className="grid grid-cols-2 gap-1">
              {categories.map(cat => {
                const isSelected = activeView === 'category' && currentCategory === cat.slug;
                return (
                  <button
                    key={cat.id}
                    onClick={() => {
                      onSelectCategory(cat.slug);
                      setMobileMenuOpen(false);
                    }}
                    className={`text-left px-3 py-2 rounded-md text-sm transition-colors ${
                      isSelected
                        ? 'bg-emerald-50 text-emerald-800 font-semibold'
                        : 'text-neutral-700 hover:bg-neutral-50'
                    }`}
                  >
                    {cat.name}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-3 flex flex-col space-y-1">
            <button
              onClick={() => {
                onOpenSearch();
                setMobileMenuOpen(false);
              }}
              className="text-left px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-md flex items-center gap-2"
            >
              <Search className="w-4 h-4 text-neutral-500" />
              <span>Search sports stories</span>
            </button>
            <button
              onClick={() => {
                onNavigateAbout();
                setMobileMenuOpen(false);
              }}
              className="text-left px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-md"
            >
              About BWS
            </button>
            <button
              onClick={() => {
                onNavigateContact();
                setMobileMenuOpen(false);
              }}
              className="text-left px-3 py-2 text-sm text-neutral-700 hover:bg-neutral-50 rounded-md"
            >
              Contact Desk
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
