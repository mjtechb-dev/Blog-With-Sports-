'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { Search, X, Eye, Calendar, ArrowRight } from 'lucide-react';
import { Article } from '../lib/types';
import { ArticleService } from '../lib/services/article-service';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectArticle: (article: Article) => void;
}

export function SearchOverlay({ isOpen, onClose, onSelectArticle }: SearchOverlayProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Article[]>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const input = document.getElementById('search-input-field');
      if (input) input.focus();
    }
  }, [isOpen]);

  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed) {
      return;
    }

    const timeout = setTimeout(() => {
      setSearching(true);
      ArticleService.search(trimmed).then(res => {
        setResults(res);
        setSearching(false);
      });
    }, 200);

    return () => clearTimeout(timeout);
  }, [query]);

  const handleClose = () => {
    setQuery('');
    setResults([]);
    onClose();
  };

  const handleQueryChange = (val: string) => {
    setQuery(val);
    if (!val.trim()) {
      setResults([]);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-neutral-900/40 backdrop-blur-xs flex items-start justify-center p-3 sm:p-6 sm:pt-16 animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-xl border border-neutral-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Search Header */}
        <div className="p-4 border-b border-neutral-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-neutral-400 shrink-0" />
          <input
            id="search-input-field"
            type="text"
            value={query}
            onChange={e => handleQueryChange(e.target.value)}
            placeholder="Search sports articles, teams, tactics, or categories..."
            className="w-full text-base sm:text-lg text-neutral-900 placeholder-neutral-400 focus:outline-none bg-transparent"
          />
          {query && (
            <button
              onClick={() => handleQueryChange('')}
              className="p-1 hover:bg-neutral-100 rounded text-neutral-400 hover:text-neutral-700"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={handleClose}
            className="px-2.5 py-1 text-xs font-semibold text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-md transition-colors"
          >
            Esc
          </button>
        </div>

        {/* Search Results Area */}
        <div className="overflow-y-auto p-4 divide-y divide-neutral-100">
          {searching && (
            <div className="py-12 text-center text-sm text-neutral-500">
              Searching sports archive...
            </div>
          )}

          {!searching && query.trim() && results.length === 0 && (
            <div className="py-12 text-center">
              <p className="text-base font-semibold text-neutral-800">No articles found</p>
              <p className="text-xs text-neutral-500 mt-1 max-w-xs mx-auto">
                No articles matched &ldquo;{query}&rdquo;. Try searching for &ldquo;Football&rdquo;, &ldquo;Real Madrid&rdquo;, or &ldquo;Tennis&rdquo;.
              </p>
            </div>
          )}

          {!searching && !query.trim() && (
            <div className="py-8 text-center text-xs text-neutral-400">
              Start typing to search international sports stories, analysis and categories.
            </div>
          )}

          {!searching && results.map(article => (
            <div
              key={article.id}
              onClick={() => {
                onSelectArticle(article);
                onClose();
              }}
              className="py-3.5 flex items-start gap-4 hover:bg-neutral-50 rounded-lg p-2 transition-colors cursor-pointer group"
            >
              <div className="relative w-20 h-16 sm:w-24 sm:h-18 rounded-md overflow-hidden bg-neutral-100 shrink-0 border border-neutral-200">
                <Image
                  src={article.featuredImage}
                  alt={article.title}
                  fill
                  sizes="96px"
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                    {article.categoryName}
                  </span>
                  <span className="text-neutral-300">·</span>
                  <span className="text-[11px] text-neutral-400">{article.readingTime}</span>
                </div>

                <h4 className="text-sm font-bold text-neutral-900 group-hover:text-emerald-800 transition-colors leading-snug line-clamp-1">
                  {article.title}
                </h4>

                <p className="text-xs text-neutral-500 line-clamp-1 mt-0.5">
                  {article.description}
                </p>

                <div className="mt-1 flex items-center gap-3 text-[11px] text-neutral-400">
                  <span>{article.authorName}</span>
                  <span>·</span>
                  <span>{article.views.toLocaleString()} views</span>
                </div>
              </div>

              <ArrowRight className="w-4 h-4 text-neutral-300 group-hover:text-emerald-800 group-hover:translate-x-0.5 transition-all self-center" />
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 bg-neutral-50 border-t border-neutral-100 text-xs text-neutral-500 flex items-center justify-between">
          <span>{results.length} results found</span>
          <span>Press ESC or click outside to close</span>
        </div>
      </div>
    </div>
  );
}
