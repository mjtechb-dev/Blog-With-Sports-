'use client';

import React from 'react';
import { Clock, Eye } from 'lucide-react';
import { Article } from '../lib/types';
import { OptimizedImage } from './OptimizedImage';

interface ArticleCardProps {
  article: Article;
  onSelect: (article: Article) => void;
  priority?: boolean;
}

export function ArticleCard({ article, onSelect, priority = false }: ArticleCardProps) {
  // Format date cleanly e.g. "Sep 9, 2026"
  const formattedDate = React.useMemo(() => {
    try {
      const d = new Date(article.publishedAt);
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return article.publishedAt;
    }
  }, [article.publishedAt]);

  const formattedViews = React.useMemo(() => {
    const v = article.views || 0;
    if (v >= 1000) {
      return `${(v / 1000).toFixed(1)}K views`;
    }
    return `${v} views`;
  }, [article.views]);

  return (
    <article
      onClick={() => onSelect(article)}
      className="group flex flex-col bg-white border border-neutral-200/90 rounded-lg overflow-hidden transition-all duration-200 hover:border-neutral-300 hover:shadow-xs cursor-pointer h-full"
    >
      {/* Featured Thumbnail */}
      <div className="relative aspect-[16/10] w-full bg-neutral-100 overflow-hidden">
        <OptimizedImage
          key={article.featuredImage}
          src={article.featuredImage}
          alt={article.title}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          className="object-cover transition-transform duration-300 group-hover:scale-[1.02]"
          priority={priority}
        />
        <div className="absolute top-2.5 left-2.5 z-10">
          <span className="inline-block bg-white/95 backdrop-blur-xs text-emerald-800 text-[11px] font-bold tracking-wider uppercase px-2 py-0.5 rounded shadow-2xs border border-neutral-200/50">
            {article.categoryName}
          </span>
        </div>
      </div>

      {/* Card Content Area */}
      <div className="p-4 sm:p-5 flex flex-col flex-1 justify-between">
        <div>
          <h3 className="font-bold text-base sm:text-lg text-neutral-900 leading-snug group-hover:text-emerald-800 transition-colors line-clamp-2">
            {article.title}
          </h3>

          <p className="mt-2 text-sm text-neutral-600 leading-relaxed line-clamp-2">
            {article.description}
          </p>
        </div>

        {/* Card Metadata Footer */}
        <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500">
          <div className="flex items-center gap-1.5 truncate mr-2">
            <span className="font-medium text-neutral-700 truncate">By {article.authorName}</span>
            <span>·</span>
            <span className="shrink-0">{formattedDate}</span>
          </div>

          <div className="flex items-center gap-2 shrink-0 text-neutral-400">
            <span className="hidden sm:inline-flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>{article.readingTime}</span>
            </span>
            <span className="hidden sm:inline">·</span>
            <span className="inline-flex items-center gap-1 text-neutral-500">
              <Eye className="w-3 h-3 text-neutral-400" />
              <span>{formattedViews}</span>
            </span>
          </div>
        </div>
      </div>
    </article>
  );
}
