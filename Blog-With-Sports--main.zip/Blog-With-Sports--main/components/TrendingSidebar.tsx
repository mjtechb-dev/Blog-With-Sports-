'use client';

import React from 'react';
import { TrendingUp, Eye } from 'lucide-react';
import { Article } from '../lib/types';

interface TrendingSidebarProps {
  articles: Article[];
  onSelect: (article: Article) => void;
}

export function TrendingSidebar({ articles, onSelect }: TrendingSidebarProps) {
  if (!articles || articles.length === 0) return null;

  return (
    <aside className="bg-white border border-neutral-200/90 rounded-xl p-5">
      <div className="flex items-center gap-2 pb-3 mb-3 border-b border-neutral-100">
        <TrendingUp className="w-4 h-4 text-emerald-800" />
        <h3 className="font-extrabold text-xs uppercase tracking-wider text-neutral-900">
          Trending Stories
        </h3>
      </div>

      <div className="divide-y divide-neutral-100">
        {articles.slice(0, 5).map((article, index) => {
          const rank = String(index + 1).padStart(2, '0');
          const formattedViews = article.views >= 1000
            ? `${(article.views / 1000).toFixed(1)}K`
            : article.views;

          return (
            <div
              key={article.id}
              onClick={() => onSelect(article)}
              className="py-3 first:pt-1 last:pb-1 group cursor-pointer flex items-start gap-3"
            >
              <span className="font-mono text-base font-bold text-neutral-300 group-hover:text-emerald-800 transition-colors shrink-0 select-none">
                {rank}
              </span>
              <div className="flex-1 min-w-0">
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 block mb-0.5">
                  {article.categoryName}
                </span>
                <h4 className="text-sm font-semibold text-neutral-800 group-hover:text-emerald-800 transition-colors leading-snug line-clamp-2">
                  {article.title}
                </h4>
                <div className="mt-1 flex items-center gap-2 text-[11px] text-neutral-400">
                  <span>{article.readingTime}</span>
                  <span>·</span>
                  <span className="inline-flex items-center gap-1 text-neutral-500">
                    <Eye className="w-3 h-3 text-neutral-400" />
                    <span>{formattedViews}</span>
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </aside>
  );
}
