'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, Clock, Eye } from 'lucide-react';
import { Article } from '../lib/types';
import { OptimizedImage } from './OptimizedImage';

interface FeaturedArticleProps {
  article: Article;
  onSelect: (article: Article) => void;
}

export function FeaturedArticle({ article, onSelect }: FeaturedArticleProps) {
  const formattedDate = React.useMemo(() => {
    try {
      const d = new Date(article.publishedAt);
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return article.publishedAt;
    }
  }, [article.publishedAt]);

  const formattedViews = React.useMemo(() => {
    const v = article.views || 0;
    if (v >= 1000) {
      return `${(v / 1000).toFixed(1)}K views`;
    }
    return `${v} views`;
  }, [article.views]);

  return (
    <div
      onClick={() => onSelect(article)}
      className="group bg-white border border-neutral-200/90 rounded-xl overflow-hidden hover:border-neutral-300 transition-all cursor-pointer"
    >
      <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
        {/* Featured Image */}
        <div className="md:col-span-7 relative aspect-[16/10] md:aspect-auto md:min-h-[340px] w-full bg-neutral-100 overflow-hidden">
          <OptimizedImage
            key={article.featuredImage}
            src={article.featuredImage}
            alt={article.title}
            fill
            sizes="(max-width: 768px) 100vw, 60vw"
            className="object-cover transition-transform duration-300 group-hover:scale-[1.01]"
            priority
          />
          <div className="absolute top-3 left-3 md:hidden z-10">
            <span className="bg-white/95 text-emerald-800 text-xs font-bold tracking-wider uppercase px-2.5 py-1 rounded shadow-2xs">
              {article.categoryName}
            </span>
          </div>
        </div>

        {/* Content Area */}
        <div className="md:col-span-5 p-5 sm:p-7 flex flex-col justify-between">
          <div>
            <div className="hidden md:flex items-center gap-2 mb-3">
              <span className="text-emerald-800 text-xs font-bold tracking-wider uppercase">
                {article.categoryName}
              </span>
              <span className="text-neutral-300">·</span>
              <span className="text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Featured Analysis
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl lg:text-[26px] font-extrabold text-neutral-900 leading-tight group-hover:text-emerald-800 transition-colors">
              {article.title}
            </h2>

            <p className="mt-3 text-neutral-600 text-sm sm:text-base leading-relaxed line-clamp-3 sm:line-clamp-4">
              {article.description}
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-neutral-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="relative w-8 h-8 rounded-full overflow-hidden bg-neutral-200 border border-neutral-200">
                  <Image
                    src={article.authorAvatar}
                    alt={article.authorName}
                    fill
                    sizes="32px"
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="text-xs">
                  <p className="font-semibold text-neutral-800">{article.authorName}</p>
                  <p className="text-neutral-500">{formattedDate} · {article.readingTime}</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-neutral-500 font-medium">
                <Eye className="w-3.5 h-3.5 text-neutral-400" />
                <span>{formattedViews}</span>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-1 text-sm font-semibold text-emerald-800 group-hover:translate-x-0.5 transition-transform">
              <span>Read Full Story</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
