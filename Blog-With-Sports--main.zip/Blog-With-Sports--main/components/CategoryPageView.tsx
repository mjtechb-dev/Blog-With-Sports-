'use client';

import React from 'react';
import { ArrowLeft, Filter } from 'lucide-react';
import { Category, Article } from '../lib/types';
import { ArticleCard } from './ArticleCard';
import { EmptyState } from './EmptyState';

interface CategoryPageViewProps {
  category: Category;
  articles: Article[];
  onSelectArticle: (article: Article) => void;
  onBackHome: () => void;
}

export function CategoryPageView({
  category,
  articles,
  onSelectArticle,
  onBackHome,
}: CategoryPageViewProps) {
  return (
    <div className="py-6 sm:py-10 max-w-6xl mx-auto px-4 animate-in fade-in duration-200">
      {/* Back button */}
      <div className="mb-4">
        <button
          onClick={onBackHome}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Sports</span>
        </button>
      </div>

      {/* Category Header */}
      <div className="bg-white border border-neutral-200 rounded-xl p-6 sm:p-8 mb-8">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
            Sports Beat
          </span>
          <span className="text-xs text-neutral-400">·</span>
          <span className="text-xs font-medium text-neutral-500">
            {articles.length} {articles.length === 1 ? 'Article' : 'Articles'}
          </span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
          {category.name}
        </h1>

        <p className="text-neutral-600 text-sm sm:text-base mt-2 max-w-2xl leading-relaxed">
          {category.description}
        </p>
      </div>

      {/* Articles Grid */}
      {articles.length === 0 ? (
        <EmptyState
          title={`No articles published in ${category.name} yet`}
          description="Our editorial correspondents are drafting coverage for this category. Please check back shortly."
          actionText="Return to Home"
          onAction={onBackHome}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article, idx) => (
            <ArticleCard
              key={article.id}
              article={article}
              onSelect={onSelectArticle}
              priority={idx < 3}
            />
          ))}
        </div>
      )}
    </div>
  );
}
