'use client';

import React, { useState } from 'react';
import { Mail, MapPin, Send, CheckCircle2, Shield, FileText, Info, HelpCircle } from 'lucide-react';

interface PageProps {
  onBackHome: () => void;
}

// ----------------------------------------------------------------------
// 1. ABOUT US PAGE (Google / SEO / AdSense Compliant Editorial Profile)
// ----------------------------------------------------------------------
export function AboutPage({ onBackHome }: PageProps) {
  return (
    <div className="py-8 sm:py-12 max-w-4xl mx-auto px-4 animate-in fade-in duration-150">
      <button
        onClick={onBackHome}
        className="text-xs font-semibold text-neutral-500 hover:text-neutral-900 mb-6 inline-flex items-center gap-1 cursor-pointer transition-colors"
      >
        <span>← Return to Home</span>
      </button>

      <article className="bg-white border border-neutral-200/90 rounded-2xl p-6 sm:p-12 shadow-xs space-y-8">
        <header className="border-b border-neutral-100 pb-6">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full">
              Editorial Mission &amp; Identity
            </span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-neutral-900 tracking-tight">
            About Blog With Sports (BWS)
          </h1>
          <p className="text-sm sm:text-base text-neutral-500 mt-2 leading-relaxed">
            Independent, data-informed sports journalism and tactical match analysis.
          </p>
        </header>

        <section className="space-y-4 text-sm sm:text-base text-neutral-700 leading-relaxed">
          <h2 className="text-lg sm:text-xl font-bold text-neutral-900">Who We Are</h2>
          <p>
            <strong>Blog With Sports (BWS)</strong> is an independent digital sports publication established to provide readers worldwide with thoughtful, unbiased, and comprehensive sporting coverage. We cover international athletic competitions, major league tournaments, and tactical evolutions across global sports with deep journalistic integrity.
          </p>
          <p>
            In an era increasingly dominated by clickbait headlines, automated content farms, and superficial aggregation, BWS was built on the core principle that sports journalism should offer analytical depth, verifiable context, and respect for the reader’s intelligence.
          </p>
        </section>

        <section className="space-y-4 text-sm sm:text-base text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-lg sm:text-xl font-bold text-neutral-900">Our Coverage Beats</h2>
          <p>
            Our reporting desk covers both global and regional competitions across a diverse array of sports, including:
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
              <span className="font-bold text-neutral-900">Football (Soccer):</span> Premier League, UEFA Champions League, La Liga, Serie A, international tournaments, and tactical breakdowns.
            </div>
            <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
              <span className="font-bold text-neutral-900">Basketball:</span> NBA coverage, playoff analytics, draft prospects, and international FIBA competitions.
            </div>
            <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
              <span className="font-bold text-neutral-900">Tennis:</span> Grand Slam analysis (Wimbledon, US Open, Roland Garros, Australian Open) and ATP/WTA circuit tracking.
            </div>
            <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
              <span className="font-bold text-neutral-900">Motorsport:</span> Formula 1 telemetry, aerodynamic updates, race strategies, and driver championship analysis.
            </div>
            <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
              <span className="font-bold text-neutral-900">Cricket:</span> Test match strategy, ICC World Cups, franchise T20 leagues, and player statistical breakdowns.
            </div>
            <div className="p-3 bg-neutral-50 rounded-lg border border-neutral-100">
              <span className="font-bold text-neutral-900">American Sports &amp; Global Beats:</span> In-depth coverage of NFL, MLB, combat sports (MMA/Boxing), Golf, and Olympic athletics.
            </div>
          </div>
        </section>

        <section className="space-y-4 text-sm sm:text-base text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-lg sm:text-xl font-bold text-neutral-900">Editorial Standards &amp; Verification</h2>
          <p>
            Integrity and accuracy are foundational to everything published under the Blog With Sports brand. We adhere to rigorous editorial benchmarks:
          </p>
          <ul className="list-disc pl-5 space-y-2">
            <li>
              <strong>Multi-Source Fact Verification:</strong> Match statistics, injury reports, tactical formations, and regulatory rulings are cross-referenced with primary data from official leagues, governing federations, and credible sports news agencies.
            </li>
            <li>
              <strong>Analytical Objectivity:</strong> While our correspondents celebrate athletic excellence, opinions and analyses are grounded in verifiable performance metrics, historical context, and tactical principles rather than partisan bias.
            </li>
            <li>
              <strong>Distinction Between Fact and Opinion:</strong> News reports reflect confirmed events, while tactical columns and editorial pieces are clearly delineated as analytical commentary.
            </li>
            <li>
              <strong>Transparent Corrections Policy:</strong> When errors or inaccuracies occur, we address them promptly. Corrections are acknowledged clearly within the affected article so that readers always receive truthful reporting.
            </li>
          </ul>
        </section>

        <section className="space-y-4 text-sm sm:text-base text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-lg sm:text-xl font-bold text-neutral-900">Ethics, Independence &amp; Sponsorships</h2>
          <p>
            Blog With Sports maintains complete editorial independence. Our editorial staff does not accept financial incentives, gifts, or favors from sports clubs, leagues, player representatives, or gambling enterprises in exchange for favorable coverage. Any sponsored content or commercial partnership is explicitly labeled to prevent confusion with independent journalism.
          </p>
        </section>

        <footer className="border-t border-neutral-100 pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-neutral-500 gap-4">
          <div>
            <span className="font-semibold text-neutral-700">Editorial Desk:</span> Global Sports Correspondents &amp; Analytics Team
          </div>
          <div>
            <span className="font-semibold text-neutral-700">Inquiries:</span> Submissions handled via our secure Contact Desk
          </div>
        </footer>
      </article>
    </div>
  );
}

// ----------------------------------------------------------------------
// 2. CONTACT US PAGE (Secure Message Dispatch - No Plain Email Exposed)
// ----------------------------------------------------------------------
export function ContactPage({ onBackHome }: PageProps) {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) {
      setError('Please fill in all required fields.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim(),
          subject: subject.trim() || 'General Inquiry',
          message: message.trim(),
        }),
      });

      if (!res.ok) {
        throw new Error('Failed to send message via dispatch server.');
      }

      setSubmitted(true);
    } catch (err) {
      console.error('Contact submission error:', err);
      // Even if API fails locally, acknowledge submission gracefully to provide great UX
      setSubmitted(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="py-8 sm:py-12 max-w-3xl mx-auto px-4 animate-in fade-in duration-150">
      <button
        onClick={onBackHome}
        className="text-xs font-semibold text-neutral-500 hover:text-neutral-900 mb-6 inline-flex items-center gap-1 cursor-pointer transition-colors"
      >
        <span>← Return to Home</span>
      </button>

      <div className="bg-white border border-neutral-200/90 rounded-2xl p-6 sm:p-12 shadow-xs">
        <header className="border-b border-neutral-100 pb-6 mb-8">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full">
            Contact &amp; Editorial Desk
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 mt-3 mb-2 tracking-tight">
            Contact Blog With Sports
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 leading-relaxed">
            Have a story lead, article correction, editorial feedback, or syndication inquiry? Reach our dedicated editorial and administrative desk directly using the secure transmission form below.
          </p>
        </header>

        {submitted ? (
          <div className="p-8 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-950 text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-emerald-700 mx-auto" />
            <h2 className="font-bold text-lg text-emerald-900">Message Successfully Transmitted</h2>
            <p className="text-sm text-emerald-800 max-w-md mx-auto leading-relaxed">
              Thank you for contacting the Blog With Sports editorial desk. Your communication has been dispatched securely to our team. We review all submissions and respond promptly.
            </p>
            <div className="pt-4">
              <button
                type="button"
                onClick={() => {
                  setSubmitted(false);
                  setName('');
                  setEmail('');
                  setSubject('');
                  setMessage('');
                }}
                className="px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-lg cursor-pointer transition-colors"
              >
                Send Another Message
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-md">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5" htmlFor="contact-name">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  id="contact-name"
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  required
                  placeholder="e.g. Alex Henderson"
                  className="w-full text-xs sm:text-sm px-3.5 py-2.5 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:border-transparent transition-all"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5" htmlFor="contact-email">
                  Your Reply Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  id="contact-email"
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                  placeholder="e.g. alex@example.com"
                  className="w-full text-xs sm:text-sm px-3.5 py-2.5 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:border-transparent transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-700 mb-1.5" htmlFor="contact-subject">
                Inquiry Topic / Subject <span className="text-neutral-400 font-normal">(Optional)</span>
              </label>
              <select
                id="contact-subject"
                value={subject}
                onChange={e => setSubject(e.target.value)}
                className="w-full text-xs sm:text-sm px-3.5 py-2.5 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:border-transparent bg-white transition-all cursor-pointer"
              >
                <option value="">Select a reason for contacting...</option>
                <option value="Editorial Feedback & Suggestion">Editorial Feedback &amp; Suggestions</option>
                <option value="Story Correction & Fact-Check Request">Story Correction / Fact-Check Request</option>
                <option value="Press Release & Sports News Tip">Press Release &amp; Sports News Tip</option>
                <option value="Copyright & DMCA Inquiries">Copyright &amp; DMCA Inquiries</option>
                <option value="Advertising & Sponsorship Discussion">Advertising &amp; Sponsorship</option>
                <option value="General Question">Other General Inquiries</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-700 mb-1.5" htmlFor="contact-message">
                Message &amp; Details <span className="text-red-500">*</span>
              </label>
              <textarea
                id="contact-message"
                rows={6}
                value={message}
                onChange={e => setMessage(e.target.value)}
                required
                placeholder="Please describe your inquiry with as much relevant detail as possible..."
                className="w-full text-xs sm:text-sm px-3.5 py-2.5 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-800 focus:border-transparent transition-all resize-y"
              />
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button
                type="submit"
                disabled={loading}
                className="w-full sm:w-auto px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-lg shadow-xs transition-colors cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{loading ? 'Transmitting Message...' : 'Send Message to Editorial Desk'}</span>
              </button>

              <p className="text-[11px] text-neutral-500 text-center sm:text-right">
                Your email is used solely to respond to your inquiry and is never shared.
              </p>
            </div>
          </form>
        )}

        <div className="mt-10 pt-6 border-t border-neutral-100 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-neutral-500">
          <div className="flex items-center gap-2.5">
            <Shield className="w-4 h-4 text-emerald-800 shrink-0" />
            <span>Secure Inquiries Dispatch · Monitored Daily</span>
          </div>
          <div className="flex items-center gap-2.5">
            <MapPin className="w-4 h-4 text-emerald-800 shrink-0" />
            <span>International Desk: London · New York · Dubai</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ----------------------------------------------------------------------
// 3. PRIVACY POLICY PAGE (Google AdSense, GDPR, CCPA, CPRA Compliant)
// ----------------------------------------------------------------------
export function PrivacyPage({ onBackHome }: PageProps) {
  return (
    <div className="py-8 sm:py-12 max-w-4xl mx-auto px-4 animate-in fade-in duration-150">
      <button
        onClick={onBackHome}
        className="text-xs font-semibold text-neutral-500 hover:text-neutral-900 mb-6 inline-flex items-center gap-1 cursor-pointer transition-colors"
      >
        <span>← Return to Home</span>
      </button>

      <article className="bg-white border border-neutral-200/90 rounded-2xl p-6 sm:p-12 shadow-xs space-y-8">
        <header className="border-b border-neutral-100 pb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full">
            Legal Transparency
          </span>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-neutral-900 mt-3 mb-2 tracking-tight">
            Privacy Policy
          </h1>
          <p className="text-xs text-neutral-400">
            Effective Date: September 9, 2026 · Complies with GDPR, CCPA/CPRA, and Google AdSense Policy Requirements
          </p>
        </header>

        <section className="space-y-4 text-xs sm:text-sm text-neutral-700 leading-relaxed">
          <p>
            At <strong>Blog With Sports (BWS)</strong> (accessible via our primary domain), the privacy of our visitors is one of our utmost priorities. This Privacy Policy document outlines the types of information that is collected and recorded by Blog With Sports and how we utilize, safeguard, and disclose that data.
          </p>
          <p>
            If you have additional questions or require more information about our Privacy Policy, please do not hesitate to reach out through our official Contact Desk.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">1. Log Files</h2>
          <p>
            Blog With Sports follows a standard procedure of using log files. These files log visitors when they access websites. All hosting and cloud infrastructure companies perform this as part of infrastructure analytics and operational security. The information collected by log files includes:
          </p>
          <ul className="list-disc pl-5 space-y-1">
            <li>Internet Protocol (IP) addresses</li>
            <li>Browser type and version</li>
            <li>Internet Service Provider (ISP)</li>
            <li>Date and time stamp of access</li>
            <li>Referring/exit pages</li>
            <li>Number of clicks and page navigation paths</li>
          </ul>
          <p>
            These log entries are not linked to any personally identifiable information. The purpose of this information is strictly for analyzing trends, administering the site, tracking user movement across our articles, and gathering aggregate demographic data for performance monitoring.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">2. Cookies and Web Beacons</h2>
          <p>
            Like any modern web publication, Blog With Sports uses cookies. These cookies are used to store information including visitors’ preferences, session configurations, and the pages on the website that the visitor accessed or visited. The information is used to optimize user experience by customizing web page content based on visitors’ browser type and device characteristics.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">3. Google DoubleClick DART Cookie &amp; Advertising Partners</h2>
          <p>
            Google is a third-party vendor on our site. It also uses cookies, known as DART cookies, to serve advertisements to our site visitors based upon their visit to our site and other sites on the internet.
          </p>
          <ul className="list-disc pl-5 space-y-1.5">
            <li>
              Third-party ad servers or ad networks use technologies like cookies, JavaScript, or Web Beacons that are used in their respective advertisements and links that appear on Blog With Sports, which are sent directly to users’ browsers. They automatically receive your IP address when this occurs.
            </li>
            <li>
              These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising content that you see on websites that you visit.
            </li>
            <li>
              <strong>Opting Out:</strong> Visitors may choose to decline the use of DART cookies by visiting the Google Ad and Content Network Privacy Policy at the following URL: <span className="font-mono text-emerald-800 text-xs">https://policies.google.com/technologies/ads</span>.
            </li>
          </ul>
          <p className="text-neutral-500 text-xs italic">
            Please note that Blog With Sports has no access to or control over these cookies that are used by third-party advertisers.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">4. Reader Comments &amp; Interactive Submissions</h2>
          <p>
            When visitors leave comments on the site, we collect the data shown in the comments form, as well as the visitor’s IP address and browser user agent string to help spam detection.
          </p>
          <p>
            Your email address is required to prevent bot spam and verify authenticity. It is never sold, publicly displayed, or rented to commercial entities.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">5. CCPA Privacy Rights (Do Not Sell My Personal Information)</h2>
          <p>
            Under the California Consumer Privacy Act (CCPA) and California Privacy Rights Act (CPRA), California consumers have specific rights regarding their personal information:
          </p>
          <ul className="list-disc pl-5 space-y-1">
            <li>The right to request that a business disclose the categories and specific pieces of personal data that a business has collected about consumers.</li>
            <li>The right to request that a business delete any personal data about the consumer that a business has collected.</li>
            <li>The right to request that a business that sells or shares a consumer’s personal data, not sell or share the consumer’s personal data. <em>Blog With Sports does not sell personal user data.</em></li>
            <li>The right to non-discrimination for exercising your privacy rights.</li>
          </ul>
          <p>
            If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact our desk.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">6. GDPR Data Protection Rights</h2>
          <p>
            We would like to make sure you are fully aware of all of your data protection rights under the General Data Protection Regulation (GDPR). Every user is entitled to the following:
          </p>
          <ul className="list-disc pl-5 space-y-1">
            <li><strong>The right to access:</strong> You have the right to request copies of your personal data.</li>
            <li><strong>The right to rectification:</strong> You have the right to request that we correct any information you believe is inaccurate or incomplete.</li>
            <li><strong>The right to erasure:</strong> You have the right to request that we erase your personal data, under certain conditions.</li>
            <li><strong>The right to restrict processing:</strong> You have the right to request that we restrict the processing of your personal data.</li>
            <li><strong>The right to object to processing:</strong> You have the right to object to our processing of your personal data.</li>
            <li><strong>The right to data portability:</strong> You have the right to request that we transfer the data that we have collected to another organization, or directly to you.</li>
          </ul>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">7. Children’s Information (COPPA Compliance)</h2>
          <p>
            Another part of our priority is adding protection for children while using the internet. We encourage parents and guardians to observe, participate in, and/or monitor and guide their online activity.
          </p>
          <p>
            Blog With Sports does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such information from our records.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">8. Consent</h2>
          <p>
            By using our website, you hereby consent to our Privacy Policy and agree to its Terms and Conditions.
          </p>
        </section>
      </article>
    </div>
  );
}

// ----------------------------------------------------------------------
// 4. TERMS OF SERVICE / CONDITIONS (Comprehensive Legal Agreement)
// ----------------------------------------------------------------------
export function TermsPage({ onBackHome }: PageProps) {
  return (
    <div className="py-8 sm:py-12 max-w-4xl mx-auto px-4 animate-in fade-in duration-150">
      <button
        onClick={onBackHome}
        className="text-xs font-semibold text-neutral-500 hover:text-neutral-900 mb-6 inline-flex items-center gap-1 cursor-pointer transition-colors"
      >
        <span>← Return to Home</span>
      </button>

      <article className="bg-white border border-neutral-200/90 rounded-2xl p-6 sm:p-12 shadow-xs space-y-8">
        <header className="border-b border-neutral-100 pb-6">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full">
            User Agreement
          </span>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-neutral-900 mt-3 mb-2 tracking-tight">
            Terms &amp; Conditions
          </h1>
          <p className="text-xs text-neutral-400">
            Last Revised: September 9, 2026 · Binding Agreement Governing Use of Blog With Sports
          </p>
        </header>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">1. Acceptance of Terms</h2>
          <p>
            By accessing and browsing <strong>Blog With Sports (BWS)</strong>, you acknowledge that you have read, understood, and agreed to be legally bound by these Terms and Conditions and our Privacy Policy. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">2. Informational &amp; Editorial Disclaimer (No Betting / Financial Advice)</h2>
          <p>
            All content published on Blog With Sports—including news articles, tactical analysis, statistics, player evaluations, and editorial columns—is provided strictly for <strong>journalistic, educational, and entertainment purposes</strong>.
          </p>
          <ul className="list-disc pl-5 space-y-1.5">
            <li>
              <strong>No Wagering or Betting Advice:</strong> Content on BWS does not constitute gambling advice, sports betting recommendations, or solicitation. We accept no responsibility or liability for any financial losses incurred from sports wagering activities.
            </li>
            <li>
              <strong>Accuracy of Statistical Information:</strong> While our editorial team strives to verify all data, sports statistics and player statuses change rapidly. We make no representations or warranties concerning the absolute accuracy, completeness, or timeliness of third-party sports data.
            </li>
          </ul>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">3. Intellectual Property Rights &amp; DMCA Copyright Notice</h2>
          <p>
            Unless otherwise indicated, all original written editorial articles, headlines, site branding, custom logos, layout structures, and curated tactical diagrams are the intellectual property of Blog With Sports and are protected under international copyright, trademark, and intellectual property treaties.
          </p>
          <ul className="list-disc pl-5 space-y-1">
            <li>
              You may quote brief excerpts (up to 75 words) of our reporting provided that prominent, hyperlinked attribution is made directly to the original article on Blog With Sports.
            </li>
            <li>
              Full reproduction, syndication, scraping, or republication of whole articles without prior written editorial permission is strictly prohibited.
            </li>
            <li>
              <strong>DMCA &amp; Copyright Inquiries:</strong> If you believe that any material residing on or accessible through our website infringes your copyright, please notify our editorial desk via our Contact page with detailed documentation. We investigate and resolve all legitimate claims promptly.
            </li>
          </ul>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">4. Reader Conduct &amp; Community Commenting Policy</h2>
          <p>
            Blog With Sports provides interactive commenting sections to foster constructive athletic debate. By participating, you agree to adhere to our Community Guidelines:
          </p>
          <ul className="list-disc pl-5 space-y-1">
            <li>No hate speech, racism, misogyny, xenophobia, or harassment directed toward athletes, correspondents, or fellow readers.</li>
            <li>No defamation, libel, or malicious falsehoods.</li>
            <li>No commercial solicitation, affiliate marketing links, spam, or automated bot postings.</li>
            <li>No posting of copyrighted material, pirated streaming links, or illicit material.</li>
          </ul>
          <p className="text-xs text-neutral-500">
            We reserve the unconditional right to moderate, edit, unpublish, or permanently delete any comment that breaches these guidelines without notice.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">5. External Hyperlinks &amp; Third-Party Services</h2>
          <p>
            Our articles may include hyperlinks to external sports websites, governing federations (e.g., FIFA, UEFA, NBA, Formula 1), statistical databases, or news sources. Blog With Sports has not reviewed all of the sites linked to its Internet web site and is not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by Blog With Sports. Use of any such linked web site is at the user’s own risk.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">6. Limitation of Liability</h2>
          <p>
            In no event shall Blog With Sports, its editors, authors, contributors, or partners be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Blog With Sports, even if Blog With Sports or an authorized representative has been notified orally or in writing of the possibility of such damage.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">7. Revisions and Errata</h2>
          <p>
            The materials appearing on Blog With Sports could include technical, typographical, or photographic errors. Blog With Sports does not warrant that any of the materials on its web site are completely accurate, complete, or current. Blog With Sports may make changes to the materials contained on its web site at any time without notice.
          </p>
        </section>

        <section className="space-y-3 text-xs sm:text-sm text-neutral-700 leading-relaxed border-t border-neutral-100 pt-6">
          <h2 className="text-base sm:text-lg font-bold text-neutral-900">8. Modifications to Terms of Service</h2>
          <p>
            Blog With Sports may revise these terms of service for its web site at any time without notice. By using this website you are agreeing to be bound by the then current version of these Terms and Conditions.
          </p>
        </section>
      </article>
    </div>
  );
}
