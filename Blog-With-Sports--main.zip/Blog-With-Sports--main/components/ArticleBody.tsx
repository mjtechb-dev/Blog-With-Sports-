'use client';

import React from 'react';

interface ArticleBodyProps {
  content: string;
}

export function ArticleBody({ content }: ArticleBodyProps) {
  // Parse markdown-style content cleanly into semantic editorial HTML
  const renderedElements = React.useMemo(() => {
    if (!content) return null;

    const lines = content.split('\n');
    const elements: React.ReactNode[] = [];
    let key = 0;
    let inList: 'ul' | 'ol' | null = null;
    let listItems: React.ReactNode[] = [];
    let inCodeBlock = false;
    let codeBlockLines: string[] = [];

    const flushList = () => {
      if (inList === 'ul' && listItems.length > 0) {
        elements.push(
          <ul key={`ul-${key++}`} className="my-5 space-y-2 list-disc list-outside pl-6 text-neutral-800 leading-relaxed">
            {listItems}
          </ul>
        );
      } else if (inList === 'ol' && listItems.length > 0) {
        elements.push(
          <ol key={`ol-${key++}`} className="my-5 space-y-2 list-decimal list-outside pl-6 text-neutral-800 leading-relaxed">
            {listItems}
          </ol>
        );
      }
      inList = null;
      listItems = [];
    };

    const flushCodeBlock = () => {
      if (inCodeBlock && codeBlockLines.length > 0) {
        elements.push(
          <div key={`code-${key++}`} className="my-6 p-4 rounded-lg bg-neutral-900 text-neutral-100 font-mono text-xs sm:text-sm overflow-x-auto leading-relaxed border border-neutral-800">
            <pre>{codeBlockLines.join('\n')}</pre>
          </div>
        );
      }
      inCodeBlock = false;
      codeBlockLines = [];
    };

    const parseInline = (text: string): React.ReactNode => {
      // Parse **bold** and *italic*
      const parts = text.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g);
      return parts.map((part, i) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return <strong key={i} className="font-bold text-neutral-950">{part.slice(2, -2)}</strong>;
        }
        if (part.startsWith('*') && part.endsWith('*')) {
          return <em key={i} className="italic">{part.slice(1, -1)}</em>;
        }
        return part;
      });
    };

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();

      // Check code fence
      if (line.startsWith('```')) {
        if (inCodeBlock) {
          flushCodeBlock();
        } else {
          flushList();
          inCodeBlock = true;
          codeBlockLines = [];
        }
        continue;
      }

      if (inCodeBlock) {
        codeBlockLines.push(lines[i]);
        continue;
      }

      // Empty line
      if (!line) {
        flushList();
        continue;
      }

      // H2
      if (line.startsWith('## ')) {
        flushList();
        elements.push(
          <h2 key={`h2-${key++}`} className="text-2xl sm:text-[26px] font-extrabold text-neutral-950 mt-10 mb-4 tracking-tight leading-snug">
            {parseInline(line.slice(3))}
          </h2>
        );
        continue;
      }

      // H3
      if (line.startsWith('### ')) {
        flushList();
        elements.push(
          <h3 key={`h3-${key++}`} className="text-xl sm:text-[22px] font-bold text-neutral-900 mt-8 mb-3 tracking-tight leading-snug">
            {parseInline(line.slice(4))}
          </h3>
        );
        continue;
      }

      // Blockquote
      if (line.startsWith('> ')) {
        flushList();
        elements.push(
          <blockquote key={`quote-${key++}`} className="my-7 pl-5 border-l-4 border-emerald-800 italic text-neutral-800 text-lg sm:text-xl font-serif leading-relaxed bg-emerald-50/40 py-3 pr-4 rounded-r">
            {parseInline(line.slice(2))}
          </blockquote>
        );
        continue;
      }

      // Bullet list
      if (line.startsWith('* ') || line.startsWith('- ')) {
        if (inList !== 'ul') {
          flushList();
          inList = 'ul';
        }
        listItems.push(
          <li key={`li-${key++}`} className="text-neutral-800 text-base sm:text-[17px] leading-relaxed">
            {parseInline(line.slice(2))}
          </li>
        );
        continue;
      }

      // Numbered list
      const numMatch = line.match(/^(\d+)\.\s+(.*)$/);
      if (numMatch) {
        if (inList !== 'ol') {
          flushList();
          inList = 'ol';
        }
        listItems.push(
          <li key={`li-${key++}`} className="text-neutral-800 text-base sm:text-[17px] leading-relaxed">
            {parseInline(numMatch[2])}
          </li>
        );
        continue;
      }

      // Standard paragraph
      flushList();
      elements.push(
        <p key={`p-${key++}`} className="my-5 text-neutral-800 text-base sm:text-[18px] leading-[1.75] font-normal">
          {parseInline(line)}
        </p>
      );
    }

    flushList();
    flushCodeBlock();

    return elements;
  }, [content]);

  return (
    <div className="article-editorial-body max-w-[70ch] mx-auto text-neutral-800">
      {renderedElements}
    </div>
  );
}
