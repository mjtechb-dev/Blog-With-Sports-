'use client';

import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { Clock, Eye, Calendar, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { Article } from '../lib/types';
import { ArticleService } from '../lib/services/article-service';
import { ArticleBody } from './ArticleBody';
import { CommentsSection } from './CommentsSection';
import { ShareButton } from './ShareButton';
import { ArticleCard } from './ArticleCard';
import { OptimizedImage } from './OptimizedImage';

interface ArticleDetailViewProps {
  article: Article;
  onBack: () => void;
  onSelectArticle: (article: Article) => void;
  onSelectCategory: (categorySlug: string) => void;
}

export function ArticleDetailView({
  article,
  onBack,
  onSelectArticle,
  onSelectCategory,
}: ArticleDetailViewProps) {
  const [currentViews, setCurrentViews] = useState(article.views);
  const [relatedArticles, setRelatedArticles] = useState<Article[]>([]);
  const [imgError, setImgError] = useState(false);

  // Increment view counter with anti-refresh session protection
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    ArticleService.registerView(article.id).then(newViews => {
      if (newViews > 0) setCurrentViews(newViews);
    });

    ArticleService.getRelated(article.id, article.categoryId, article.tags, 3).then(related => {
      setRelatedArticles(related);
    });
  }, [article.id, article.categoryId, article.tags]);

  const formattedDate = React.useMemo(() => {
    try {
      const d = new Date(article.publishedAt);
      return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    } catch {
      return article.publishedAt;
    }
  }, [article.publishedAt]);

  const formattedViews = React.useMemo(() => {
    const v = currentViews || 0;
    return `${v.toLocaleString()} views`;
  }, [currentViews]);

  return (
    <article className="py-6 sm:py-10 animate-in fade-in duration-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Navigation Breadcrumb / Back */}
        <div className="flex items-center justify-between gap-4 mb-6">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-600 hover:text-neutral-900 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Stories</span>
          </button>

          <button
            onClick={() => onSelectCategory(article.categoryId)}
            className="text-xs font-bold uppercase tracking-wider text-emerald-800 hover:text-emerald-950 transition-colors bg-emerald-50 px-2.5 py-1 rounded"
          >
            {article.categoryName}
          </button>
        </div>

        {/* Article Header (PRD Section 12) */}
        <header className="mb-8">
          <h1 className="text-2xl sm:text-4xl lg:text-[42px] font-extrabold text-neutral-950 tracking-tight leading-[1.18] mb-4">
            {article.title}
          </h1>

          <p className="text-base sm:text-xl text-neutral-600 font-normal leading-relaxed mb-6 max-w-[68ch]">
            {article.description}
          </p>

          {/* Author & Meta Bar */}
          <div className="pt-4 border-t border-b border-neutral-200/80 py-3.5 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="relative w-11 h-11 rounded-full overflow-hidden bg-neutral-200 border border-neutral-200 shrink-0">
                <Image
                  src={article.authorAvatar}
                  alt={article.authorName}
                  fill
                  sizes="44px"
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-neutral-900 text-sm">{article.authorName}</span>
                  <span className="text-neutral-400">·</span>
                  <span className="text-neutral-500 font-medium">{article.authorRole}</span>
                </div>
                <div className="flex items-center gap-2 text-neutral-500 mt-0.5">
                  <span>Published: {formattedDate}</span>
                  {article.updatedAt && (
                    <>
                      <span>·</span>
                      <span className="text-neutral-400">Updated: {article.updatedAt}</span>
                    </>
                  )}
                  <span>·</span>
                  <span className="text-neutral-600 font-medium">{article.readingTime}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="inline-flex items-center gap-1.5 text-xs text-neutral-600 font-medium bg-neutral-100/80 px-2.5 py-1.5 rounded-md">
                <Eye className="w-3.5 h-3.5 text-neutral-500" />
                <span>{formattedViews}</span>
              </div>
              <ShareButton title={article.title} />
            </div>
          </div>
        </header>

        {/* Large Featured Image with Caption */}
        <div className="mb-10">
          <div className="relative aspect-[16/9] w-full rounded-xl overflow-hidden bg-neutral-100 border border-neutral-200/90 shadow-2xs">
            <OptimizedImage
              key={article.featuredImage}
              src={article.featuredImage}
              alt={article.title}
              fill
              sizes="(max-width: 896px) 100vw, 896px"
              className="object-cover"
              priority
            />
          </div>
          {article.featuredImageCaption && (
            <p className="text-xs text-neutral-500 mt-2.5 italic text-center max-w-2xl mx-auto">
              {article.featuredImageCaption}
            </p>
          )}
        </div>

        {/* Semantic Article Body */}
        <ArticleBody content={article.content} />

        {/* Article Tags */}
        {article.tags && article.tags.length > 0 && (
          <div className="mt-10 pt-6 border-t border-neutral-200 max-w-[70ch] mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2">
              Filed Under:
            </span>
            <div className="flex flex-wrap gap-2">
              {article.tags.map(tag => (
                <span
                  key={tag}
                  className="px-2.5 py-1 text-xs bg-neutral-100 text-neutral-700 font-medium rounded hover:bg-neutral-200 transition-colors"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Author Bio Box */}
        <div className="mt-10 max-w-[70ch] mx-auto p-5 sm:p-6 bg-white border border-neutral-200 rounded-xl flex items-start gap-4">
          <div className="relative w-14 h-14 rounded-full overflow-hidden bg-neutral-100 border border-neutral-200 shrink-0">
            <Image
              src={article.authorAvatar}
              alt={article.authorName}
              fill
              sizes="56px"
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
              Written by
            </span>
            <h4 className="font-bold text-base text-neutral-900 mt-0.5">{article.authorName}</h4>
            <p className="text-xs text-neutral-500 font-medium">{article.authorRole}</p>
            <p className="text-xs sm:text-sm text-neutral-600 mt-2 leading-relaxed">
              Covering high-stakes international sports, competitive analysis, and tactical systems for Blog With Sports.
            </p>
          </div>
        </div>

        {/* Related Articles Section (PRD Section 21) */}
        {relatedArticles.length > 0 && (
          <section className="mt-14 pt-10 border-t border-neutral-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-neutral-900">
                Related Stories in {article.categoryName}
              </h3>
              <button
                onClick={() => onSelectCategory(article.categoryId)}
                className="text-xs font-semibold text-emerald-800 hover:underline"
              >
                View all in {article.categoryName}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {relatedArticles.map(rel => (
                <ArticleCard
                  key={rel.id}
                  article={rel}
                  onSelect={onSelectArticle}
                />
              ))}
            </div>
          </section>
        )}

        {/* Comments Section (PRD Section 17) */}
        <CommentsSection articleId={article.id} />
      </div>
    </article>
  );
}
