'use client';

import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { Comment } from '../lib/types';
import { CommentService } from '../lib/services/comment-service';

interface CommentsSectionProps {
  articleId: string;
}

export function CommentsSection({ articleId }: CommentsSectionProps) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [commentText, setCommentText] = useState('');
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    CommentService.getByArticleId(articleId, true).then(data => {
      if (mounted) setComments(data);
    });
    return () => {
      mounted = false;
    };
  }, [articleId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!name.trim()) {
      setErrorMsg('Please enter your name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('A valid email address is required (kept strictly confidential).');
      return;
    }
    if (!commentText.trim()) {
      setErrorMsg('Please write your comment before submitting.');
      return;
    }

    setLoading(true);
    try {
      const res = await CommentService.submitComment({
        articleId,
        name: name.trim(),
        email: email.trim(),
        comment: commentText.trim(),
      });

      setSuccessMsg(res.message);
      setName('');
      setEmail('');
      setCommentText('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to submit comment. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (isoString: string) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return isoString;
    }
  };

  return (
    <section className="mt-14 pt-10 border-t border-neutral-200">
      <div className="max-w-[70ch] mx-auto">
        <div className="flex items-center gap-2 mb-6">
          <MessageSquare className="w-5 h-5 text-emerald-800" />
          <h3 className="text-xl font-bold text-neutral-900">
            Comments ({comments.length})
          </h3>
        </div>

        {/* Comment Form */}
        <div className="bg-neutral-50/80 border border-neutral-200 rounded-lg p-5 sm:p-6 mb-10">
          <h4 className="text-sm font-semibold text-neutral-800 mb-1">Leave a Thoughtful Comment</h4>
          <p className="text-xs text-neutral-500 mb-4">
            Your email address is required for editorial verification and will not be published.
          </p>

          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-md text-emerald-800 text-xs flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md text-red-700 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  Your Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. John Henderson"
                  required
                  className="w-full px-3 py-2 text-sm bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800 focus:border-emerald-800"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  required
                  className="w-full px-3 py-2 text-sm bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800 focus:border-emerald-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Comment <span className="text-red-500">*</span>
              </label>
              <textarea
                rows={3}
                value={commentText}
                onChange={e => setCommentText(e.target.value)}
                placeholder="Share your perspective on the tactics, key moments, or analysis..."
                required
                className="w-full px-3 py-2 text-sm bg-white border border-neutral-300 rounded-md focus:outline-none focus:ring-1 focus:ring-emerald-800 focus:border-emerald-800 resize-y"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-md transition-colors shadow-2xs cursor-pointer disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{loading ? 'Submitting...' : 'Post Comment'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Existing Comments List */}
        <div className="space-y-4">
          {comments.length === 0 ? (
            <div className="text-center py-8 px-4 bg-white border border-dashed border-neutral-200 rounded-lg">
              <p className="text-sm text-neutral-500">No public comments yet. Be the first to share your thoughts!</p>
            </div>
          ) : (
            comments.map(c => (
              <div key={c.id} className="bg-white border border-neutral-200/90 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-sm text-neutral-900">{c.name}</span>
                  <span className="text-xs text-neutral-400">{formatDate(c.createdAt)}</span>
                </div>
                <p className="text-sm text-neutral-700 leading-relaxed whitespace-pre-line">
                  {c.comment}
                </p>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
