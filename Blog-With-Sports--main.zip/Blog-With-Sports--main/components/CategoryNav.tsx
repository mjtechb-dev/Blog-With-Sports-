'use client';

import React from 'react';
import { Category } from '../lib/types';

interface CategoryNavProps {
  categories: Category[];
  selectedCategory?: string;
  onSelectCategory: (slug: string) => void;
  onSelectAll?: () => void;
}

export function CategoryNav({
  categories,
  selectedCategory,
  onSelectCategory,
  onSelectAll,
}: CategoryNavProps) {
  return (
    <div className="border-b border-neutral-200/80 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 mr-1 hidden sm:inline-block shrink-0">
            Categories:
          </span>

          <button
            onClick={() => onSelectAll && onSelectAll()}
            className={`text-xs font-semibold px-3 py-1.5 rounded-full transition-colors shrink-0 ${
              !selectedCategory
                ? 'bg-neutral-900 text-white'
                : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
            }`}
          >
            All Sports
          </button>

          {categories.map(cat => {
            const isSelected = selectedCategory === cat.slug;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.slug)}
                className={`text-xs font-semibold px-3 py-1.5 rounded-full transition-colors shrink-0 ${
                  isSelected
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
                }`}
              >
                {cat.name}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
