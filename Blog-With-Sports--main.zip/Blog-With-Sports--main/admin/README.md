# Blog With Sports (BWS) — Standalone Editorial Admin Portal

This is the independent, portable administrative portal designed for **Blog With Sports**. It is built strictly with **HTML5, CSS3, and vanilla JavaScript (ES6)** with direct Firebase Firestore cloud sync.

## How to Download & Use

1. **Download this `/admin` folder** directly to your computer (or keep it in a secure local directory).
2. Once downloaded, you can safely delete the `/admin` folder from the live web server if you wish to keep your admin interface 100% private and offline on your computer.
3. Open `index.html` on your computer in any web browser (Chrome, Edge, Safari, Firefox).
4. Because it connects directly to your Firebase Firestore cloud project (`lg-topup`), publishing, editing, or uploading images to ImgBB from your computer will **instantly update the live website** in real-time!

## Files in this package:
- `index.html` — The main admin interface with SEO options, live Google Snippet preview, ImgBB direct uploader, and article editor.
- `styles.css` — High-performance modern dashboard styles with zero external dependencies.
- `app.js` — Core JavaScript connecting directly to Firebase Firestore and ImgBB.
