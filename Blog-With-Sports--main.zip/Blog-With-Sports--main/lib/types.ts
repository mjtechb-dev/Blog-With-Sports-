export interface ArticleSEO {
  seoTitle: string;
  metaDescription: string;
  canonicalUrl?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  keywords?: string[];
  robots?: string;
}

export interface Author {
  id: string;
  name: string;
  role: string;
  avatar: string;
  bio: string;
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  categoryId: string;
  categoryName: string;
  tags: string[];
  description: string;
  content: string; // Markdown or rich structured HTML
  featuredImage: string;
  featuredImageCaption?: string;
  authorId: string;
  authorName: string;
  authorRole: string;
  authorAvatar: string;
  publishedAt: string;
  updatedAt?: string;
  status: 'draft' | 'published';
  views: number;
  readingTime: string;
  isTrending?: boolean;
  isFeatured?: boolean;
  seo: ArticleSEO;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  status: 'active' | 'disabled';
  order: number;
}

export interface Comment {
  id: string;
  articleId: string;
  name: string;
  email: string;
  comment: string;
  createdAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface AnalyticsSummary {
  todayVisitors: number;
  totalVisitors: number;
  todayPageViews: number;
  totalArticleViews: number;
  publishedArticlesCount: number;
  totalArticlesCount: number;
  pendingCommentsCount: number;
  recentTraffic: { date: string; views: number; visitors: number }[];
}

export interface SiteSettings {
  siteName: string;
  siteTagline: string;
  siteDescription: string;
  defaultAuthor: string;
  contactEmail: string;
  editorialDeskLocation: string;
  defaultMetaTitle: string;
  defaultMetaDescription: string;
}
