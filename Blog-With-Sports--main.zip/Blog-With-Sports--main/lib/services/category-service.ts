import { Category } from '../types';
import { INITIAL_CATEGORIES } from '../initial-data';
import { getStoredData, setStoredData } from './storage-helper';

const CATEGORY_STORAGE_KEY = 'bws_categories_v1';

class CategoryServiceClass {
  private getCategoriesList(): Category[] {
    return getStoredData<Category[]>(CATEGORY_STORAGE_KEY, INITIAL_CATEGORIES);
  }

  private saveCategoriesList(cats: Category[]): void {
    setStoredData(CATEGORY_STORAGE_KEY, cats);
  }

  public async getAll(onlyActive = true): Promise<Category[]> {
    const list = this.getCategoriesList();
    const sorted = [...list].sort((a, b) => a.order - b.order);
    if (onlyActive) {
      return sorted.filter(c => c.status === 'active');
    }
    return sorted;
  }

  public async getBySlug(slug: string): Promise<Category | null> {
    const list = this.getCategoriesList();
    const cat = list.find(c => c.slug.toLowerCase() === slug.toLowerCase());
    return cat || null;
  }

  public async create(data: Omit<Category, 'id'>): Promise<Category> {
    const list = this.getCategoriesList();
    const id = data.slug.toLowerCase().replace(/\s+/g, '-');
    const newCat: Category = {
      ...data,
      id,
    };
    list.push(newCat);
    this.saveCategoriesList(list);
    return newCat;
  }

  public async update(id: string, updates: Partial<Category>): Promise<Category | null> {
    const list = this.getCategoriesList();
    const index = list.findIndex(c => c.id === id);
    if (index === -1) return null;

    list[index] = { ...list[index], ...updates };
    this.saveCategoriesList(list);
    return list[index];
  }

  public async delete(id: string): Promise<boolean> {
    const list = this.getCategoriesList();
    const nextList = list.filter(c => c.id !== id);
    if (nextList.length === list.length) return false;
    this.saveCategoriesList(nextList);
    return true;
  }
}

export const CategoryService = new CategoryServiceClass();
