import { Comment } from '../types';
import { INITIAL_COMMENTS } from '../initial-data';
import { getStoredData, setStoredData } from './storage-helper';

const COMMENT_STORAGE_KEY = 'bws_comments_v2';

class CommentServiceClass {
  private getCommentsList(): Comment[] {
    if (typeof window !== 'undefined') {
      try {
        if (localStorage.getItem('bws_comments_v1')) localStorage.removeItem('bws_comments_v1');
      } catch {}
    }
    return getStoredData<Comment[]>(COMMENT_STORAGE_KEY, INITIAL_COMMENTS);
  }

  private saveCommentsList(comments: Comment[]): void {
    setStoredData(COMMENT_STORAGE_KEY, comments);
  }

  public async getByArticleId(articleId: string, onlyApproved = true): Promise<Comment[]> {
    const list = this.getCommentsList();
    return list
      .filter(c => c.articleId === articleId && (!onlyApproved || c.status === 'approved'))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public async getAll(statusFilter?: 'pending' | 'approved' | 'rejected' | 'all'): Promise<Comment[]> {
    const list = this.getCommentsList();
    if (!statusFilter || statusFilter === 'all') {
      return [...list].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    return list
      .filter(c => c.status === statusFilter)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public async submitComment(data: {
    articleId: string;
    name: string;
    email: string;
    comment: string;
  }): Promise<{ comment: Comment; message: string }> {
    // Validation
    const cleanName = data.name.trim();
    const cleanEmail = data.email.trim();
    const cleanComment = data.comment.trim();

    if (!cleanName || cleanName.length < 2) {
      throw new Error('Please provide your name.');
    }
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      throw new Error('A valid email address is required.');
    }
    if (!cleanComment || cleanComment.length < 3) {
      throw new Error('Comment text is required.');
    }

    const list = this.getCommentsList();
    const newComment: Comment = {
      id: `comm-${Date.now()}`,
      articleId: data.articleId,
      name: cleanName,
      email: cleanEmail,
      comment: cleanComment,
      createdAt: new Date().toISOString(),
      // Submitted comments start as pending for admin approval
      status: 'pending',
    };

    list.unshift(newComment);
    this.saveCommentsList(list);

    return {
      comment: newComment,
      message: 'Thank you for your comment! It has been submitted to the editorial desk for review and will appear once approved.',
    };
  }

  public async updateStatus(id: string, status: 'approved' | 'rejected'): Promise<boolean> {
    const list = this.getCommentsList();
    const index = list.findIndex(c => c.id === id);
    if (index === -1) return false;

    list[index].status = status;
    this.saveCommentsList(list);
    return true;
  }

  public async delete(id: string): Promise<boolean> {
    const list = this.getCommentsList();
    const nextList = list.filter(c => c.id !== id);
    if (nextList.length === list.length) return false;
    this.saveCommentsList(nextList);
    return true;
  }
}

export const CommentService = new CommentServiceClass();
