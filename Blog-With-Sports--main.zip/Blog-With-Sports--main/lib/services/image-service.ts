/**
 * ImageService abstraction
 * Supports ImgBB upload integration with automatic API key fallback,
 * local object reader fallback, and sports editorial presets.
 */

export const IMGBB_API_KEY_DEFAULT = 'b9f93bd32768a501e8f114add1a0a2a3';

export interface PresetSportsImage {
  id: string;
  category: string;
  label: string;
  url: string;
  caption: string;
}

export const SPORTS_STOCK_PRESETS: PresetSportsImage[] = [
  {
    id: 'f1',
    category: 'Football',
    label: 'Santiago Bernabéu Floodlights',
    url: 'https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=1200&auto=format&fit=crop&q=80',
    caption: 'European Champions League match under stadium floodlights.',
  },
  {
    id: 'f2',
    category: 'Football',
    label: 'Tactical Pitch & Ball Action',
    url: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=1200&auto=format&fit=crop&q=80',
    caption: 'Player executing a precision cross under match pressure.',
  },
  {
    id: 'b1',
    category: 'Basketball',
    label: 'Hardwood Fastbreak',
    url: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=1200&auto=format&fit=crop&q=80',
    caption: 'Perimeter motion during a high-stakes regular season contest.',
  },
  {
    id: 't1',
    category: 'Tennis',
    label: 'Arthur Ashe Baseline Arena',
    url: 'https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=1200&auto=format&fit=crop&q=80',
    caption: 'Flushing Meadows evening match during deciding set tiebreak.',
  },
  {
    id: 'm1',
    category: 'Motorsport',
    label: 'Formula 1 Pitlane & Chassis',
    url: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=1200&auto=format&fit=crop&q=80',
    caption: 'Trackside engineering checks on rear wing and floor diffuser assembly.',
  },
  {
    id: 'c1',
    category: 'Cricket',
    label: 'Test Match Red Ball & Seam',
    url: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=1200&auto=format&fit=crop&q=80',
    caption: 'Fast bowler preparing the Duke red ball before bowling an over.',
  },
  {
    id: 'bb1',
    category: 'Baseball',
    label: 'Mound Pitching Velocity',
    url: 'https://images.unsplash.com/photo-1508344928928-7165b67de128?w=1200&auto=format&fit=crop&q=80',
    caption: 'Late-inning relief pitcher finishing high-velocity delivery.',
  },
];

export interface UploadResult {
  url: string;
  displayUrl?: string;
  deleteUrl?: string;
  source: 'imgbb' | 'local';
}

class ImageServiceClass {
  /**
   * Upload an image to ImgBB via the Next.js API route (/api/upload)
   * or directly to ImgBB API with automatic fallbacks.
   */
  public async upload(file: File, customApiKey?: string): Promise<UploadResult> {
    // 1. Try server-side proxy route first (/api/upload)
    try {
      const formData = new FormData();
      formData.append('image', file);
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && json.url) {
          return {
            url: json.url,
            displayUrl: json.displayUrl || json.url,
            deleteUrl: json.deleteUrl,
            source: 'imgbb',
          };
        }
      }
    } catch (routeErr) {
      console.warn('Upload via /api/upload encountered error, trying direct ImgBB:', routeErr);
    }

    // 2. Fallback: Direct upload to ImgBB client-side API
    const key =
      customApiKey ||
      (typeof process !== 'undefined' ? process.env.NEXT_PUBLIC_IMGBB_API_KEY : '') ||
      IMGBB_API_KEY_DEFAULT;

    if (key) {
      try {
        const formData = new FormData();
        formData.append('image', file);
        const res = await fetch(`https://api.imgbb.com/1/upload?key=${key}`, {
          method: 'POST',
          body: formData,
        });

        const data = await res.json();
        if (data && data.success && data.data && data.data.url) {
          return {
            url: data.data.url,
            displayUrl: data.data.display_url || data.data.url,
            deleteUrl: data.data.delete_url,
            source: 'imgbb',
          };
        }
      } catch (directErr) {
        console.warn('Direct ImgBB upload error, falling back to local reader:', directErr);
      }
    }

    // 3. Fallback: Base64 data reader for offline resilience
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        resolve({
          url: reader.result as string,
          source: 'local',
        });
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  public getStockPresets(): PresetSportsImage[] {
    return SPORTS_STOCK_PRESETS;
  }
}

export const ImageService = new ImageServiceClass();
