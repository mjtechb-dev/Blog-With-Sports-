import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  increment,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../firebase';
import { Article } from '../types';
import { getStoredData, setStoredData } from './storage-helper';

const STORAGE_KEY = 'bws_articles_v3';
const VIEWED_SESSION_KEY = 'bws_viewed_articles_v1';
const ARTICLES_COLLECTION = 'articles';

class ArticleServiceClass {
  private localFallbackList(): Article[] {
    const raw = getStoredData<Article[]>(STORAGE_KEY, []);
    const demoIds = new Set(['art-1', 'art-2', 'art-3', 'art-4', 'art-5', 'art-6']);
    return raw.filter(a => !demoIds.has(a.id));
  }

  private saveLocalCache(articles: Article[]): void {
    setStoredData(STORAGE_KEY, articles);
  }

  /**
   * Subscribe to real-time articles updates from Firestore
   */
  public subscribeToArticles(callback: (articles: Article[]) => void): () => void {
    try {
      const q = query(collection(db, ARTICLES_COLLECTION), orderBy('publishedAt', 'desc'));
      return onSnapshot(
        q,
        (snapshot) => {
          const list: Article[] = [];
          snapshot.forEach((d) => {
            const data = d.data();
            list.push({
              id: d.id,
              ...data,
            } as Article);
          });
          if (list.length > 0) {
            this.saveLocalCache(list);
            callback(list);
          } else {
            callback(this.localFallbackList());
          }
        },
        (error) => {
          console.warn('Firestore snapshot listener warning:', error);
          callback(this.localFallbackList());
        }
      );
    } catch (err) {
      console.warn('Firestore subscription error:', err);
      callback(this.localFallbackList());
      return () => {};
    }
  }

  /**
   * Fetch all articles (Firestore primary, LocalStorage fallback)
   */
  public async getAll(options?: {
    categorySlug?: string;
    status?: 'published' | 'draft' | 'all';
    limit?: number;
  }): Promise<Article[]> {
    let list: Article[] = [];

    try {
      const snapshot = await getDocs(collection(db, ARTICLES_COLLECTION));
      if (!snapshot.empty) {
        snapshot.forEach((d) => {
          const data = d.data();
          list.push({
            id: d.id,
            ...data,
          } as Article);
        });
        this.saveLocalCache(list);
      } else {
        list = this.localFallbackList();
      }
    } catch (error) {
      console.warn('Firestore getAll fallback to local:', error);
      list = this.localFallbackList();
    }

    const statusFilter = options?.status || 'published';
    let filtered = list;
    if (statusFilter !== 'all') {
      filtered = filtered.filter(a => a.status === statusFilter);
    }

    if (options?.categorySlug) {
      const cat = options.categorySlug.toLowerCase();
      filtered = filtered.filter(
        a => a.categoryId.toLowerCase() === cat || a.categoryName.toLowerCase() === cat
      );
    }

    filtered.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());

    if (options?.limit) {
      return filtered.slice(0, options.limit);
    }
    return filtered;
  }

  public async getBySlug(slug: string): Promise<Article | null> {
    const cleanSlug = slug.toLowerCase().trim();
    try {
      const q = query(
        collection(db, ARTICLES_COLLECTION),
        where('slug', '==', cleanSlug)
      );
      const snapshot = await getDocs(q);
      if (!snapshot.empty) {
        const first = snapshot.docs[0];
        return { id: first.id, ...first.data() } as Article;
      }
    } catch (error) {
      console.warn('Firestore getBySlug fallback:', error);
    }

    // Fallback to cached list
    const cached = this.localFallbackList();
    return cached.find(a => a.slug.toLowerCase() === cleanSlug) || null;
  }

  public async getById(id: string): Promise<Article | null> {
    try {
      const docRef = doc(db, ARTICLES_COLLECTION, id);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        return { id: snap.id, ...snap.data() } as Article;
      }
    } catch (error) {
      console.warn('Firestore getById fallback:', error);
    }

    const cached = this.localFallbackList();
    return cached.find(a => a.id === id) || null;
  }

  public async getFeatured(): Promise<Article | null> {
    const list = await this.getAll({ status: 'published' });
    const featured = list.find(a => a.isFeatured);
    return featured || list[0] || null;
  }

  public async getTrending(limit = 4): Promise<Article[]> {
    const list = await this.getAll({ status: 'published' });
    const sorted = [...list].sort((a, b) => (b.views || 0) - (a.views || 0));
    return sorted.slice(0, limit);
  }

  public async getRelated(articleId: string, categoryId: string, tags: string[] = [], limit = 3): Promise<Article[]> {
    const all = await this.getAll({ status: 'published' });
    const others = all.filter(a => a.id !== articleId);

    const scored = others.map(art => {
      let score = 0;
      if (art.categoryId.toLowerCase() === categoryId.toLowerCase()) score += 3;
      art.tags.forEach(t => {
        if (tags.some(tag => tag.toLowerCase() === t.toLowerCase())) score += 1;
      });
      return { article: art, score };
    });

    scored.sort((a, b) => b.score - a.score || b.article.views - a.article.views);
    return scored.slice(0, limit).map(s => s.article);
  }

  public async search(queryText: string): Promise<Article[]> {
    const q = queryText.trim().toLowerCase();
    if (!q) return [];

    const all = await this.getAll({ status: 'published' });
    return all.filter(art => {
      return (
        art.title.toLowerCase().includes(q) ||
        art.description.toLowerCase().includes(q) ||
        art.categoryName.toLowerCase().includes(q) ||
        art.tags.some(t => t.toLowerCase().includes(q)) ||
        art.authorName.toLowerCase().includes(q)
      );
    });
  }

  /**
   * Create new article (writes to Firestore and updates local cache)
   */
  public async create(articleData: Omit<Article, 'id' | 'views'>): Promise<Article> {
    const id = `art-${Date.now()}`;
    const newArticle: Article = {
      ...articleData,
      id,
      views: 0,
    };

    try {
      await setDoc(doc(db, ARTICLES_COLLECTION, id), newArticle);
    } catch (error) {
      console.warn('Firestore create error, saving locally:', error);
    }

    const local = this.localFallbackList();
    local.unshift(newArticle);
    this.saveLocalCache(local);
    return newArticle;
  }

  /**
   * Update article
   */
  public async update(id: string, updates: Partial<Article>): Promise<Article | null> {
    const payload = {
      ...updates,
      updatedAt: new Date().toISOString().split('T')[0],
    };

    try {
      await updateDoc(doc(db, ARTICLES_COLLECTION, id), payload);
    } catch (error) {
      console.warn('Firestore update error:', error);
    }

    const local = this.localFallbackList();
    const index = local.findIndex(a => a.id === id);
    if (index !== -1) {
      local[index] = { ...local[index], ...payload };
      this.saveLocalCache(local);
      return local[index];
    }
    return null;
  }

  /**
   * Delete article
   */
  public async delete(id: string): Promise<boolean> {
    try {
      await deleteDoc(doc(db, ARTICLES_COLLECTION, id));
    } catch (error) {
      console.warn('Firestore delete error:', error);
    }

    const local = this.localFallbackList();
    const next = local.filter(a => a.id !== id);
    this.saveLocalCache(next);
    return true;
  }

  /**
   * Register article view with increment in Firestore
   */
  public async registerView(slugOrId: string): Promise<number> {
    // Check sessionStorage to prevent repeated counting on refresh
    if (typeof window !== 'undefined') {
      try {
        const rawViewed = window.sessionStorage.getItem(VIEWED_SESSION_KEY);
        const viewedSet: string[] = rawViewed ? JSON.parse(rawViewed) : [];
        if (viewedSet.includes(slugOrId)) {
          return 0;
        }
        viewedSet.push(slugOrId);
        window.sessionStorage.setItem(VIEWED_SESSION_KEY, JSON.stringify(viewedSet));
      } catch (err) {
        console.warn('Session storage error:', err);
      }
    }

    // Try increment in Firestore
    try {
      const article = await this.getBySlug(slugOrId) || await this.getById(slugOrId);
      if (article) {
        const docRef = doc(db, ARTICLES_COLLECTION, article.id);
        await updateDoc(docRef, {
          views: increment(1)
        });
        return (article.views || 0) + 1;
      }
    } catch (err) {
      console.warn('Firestore view register warning:', err);
    }

    return 1;
  }
}

export const ArticleService = new ArticleServiceClass();
