import { getStoredData, setStoredData } from './storage-helper';

const AUTH_STORAGE_KEY = 'bws_auth_admin_v1';

export interface AdminUser {
  email: string;
  name: string;
  role: string;
}

class AuthServiceClass {
  public isAuthenticated(): boolean {
    if (typeof window === 'undefined') return false;
    const user = getStoredData<AdminUser | null>(AUTH_STORAGE_KEY, null);
    return user !== null;
  }

  public getCurrentUser(): AdminUser | null {
    return getStoredData<AdminUser | null>(AUTH_STORAGE_KEY, null);
  }

  public async login(email: string, password: string):Promise<AdminUser> {
    const cleanEmail = email.trim().toLowerCase();
    
    // Support standard admin credentials or demo convenience
    if ((cleanEmail === 'editor@blogwithsports.com' && password === 'bws2026') || password === 'admin' || password === 'bws2026' || cleanEmail.includes('admin') || cleanEmail.includes('editor')) {
      const user: AdminUser = {
        email: cleanEmail || 'editor@blogwithsports.com',
        name: 'Chief Editorial Lead',
        role: 'Senior Editor',
      };
      setStoredData(AUTH_STORAGE_KEY, user);
      return user;
    }

    throw new Error('Invalid email or password. Use demo login or editor@blogwithsports.com / bws2026');
  }

  public logout(): void {
    if (typeof window === 'undefined') return;
    try {
      window.localStorage.removeItem(AUTH_STORAGE_KEY);
    } catch (e) {
      console.warn('Logout storage error:', e);
    }
  }
}

export const AuthService = new AuthServiceClass();
