import { doc, getDoc, setDoc, updateDoc, increment } from 'firebase/firestore';
import { db } from '../firebase';
import { AnalyticsSummary } from '../types';
import { ArticleService } from './article-service';
import { CommentService } from './comment-service';

const SESSION_VISIT_KEY = 'bws_visited_session';

export interface SiteAnalytics {
  totalPageviews: number;
  uniqueVisits: number;
  lastVisitedAt?: string;
}

class AnalyticsServiceClass {
  private fallbackData: SiteAnalytics = {
    totalPageviews: 0,
    uniqueVisits: 0,
  };

  /**
   * Records a site visit in Firestore analytics/traffic
   */
  public async recordVisit(): Promise<void> {
    if (typeof window === 'undefined') return;

    const isFirstVisitInSession = !window.sessionStorage.getItem(SESSION_VISIT_KEY);
    if (isFirstVisitInSession) {
      try {
        window.sessionStorage.setItem(SESSION_VISIT_KEY, 'true');
      } catch {}
    }

    try {
      const trafficDocRef = doc(db, 'analytics', 'traffic');
      const docSnap = await getDoc(trafficDocRef);

      if (!docSnap.exists()) {
        await setDoc(trafficDocRef, {
          totalPageviews: 1,
          uniqueVisits: 1,
          lastVisitedAt: new Date().toISOString(),
        });
      } else {
        await updateDoc(trafficDocRef, {
          totalPageviews: increment(1),
          ...(isFirstVisitInSession ? { uniqueVisits: increment(1) } : {}),
          lastVisitedAt: new Date().toISOString(),
        });
      }
    } catch (err) {
      console.warn('Analytics record error:', err);
      this.fallbackData.totalPageviews += 1;
      if (isFirstVisitInSession) this.fallbackData.uniqueVisits += 1;
    }
  }

  /**
   * Fetches the current traffic & readership statistics from Firestore
   */
  public async getAnalytics(): Promise<SiteAnalytics> {
    try {
      const trafficDocRef = doc(db, 'analytics', 'traffic');
      const docSnap = await getDoc(trafficDocRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          totalPageviews: data.totalPageviews || 0,
          uniqueVisits: data.uniqueVisits || 0,
          lastVisitedAt: data.lastVisitedAt,
        };
      }
    } catch (err) {
      console.warn('Analytics fetch error:', err);
    }
    return this.fallbackData;
  }

  /**
   * Returns complete AnalyticsSummary for Admin Dashboard
   */
  public async getSummary(): Promise<AnalyticsSummary> {
    const siteStats = await this.getAnalytics();
    const articles = await ArticleService.getAll({ status: 'all' });
    const pendingComments = await CommentService.getAll('pending');

    const publishedArticles = articles.filter(a => a.status === 'published');
    const totalArticleViews = articles.reduce((sum, a) => sum + (a.views || 0), 0);

    const todayStr = new Date().toISOString().split('T')[0];
    const recentTraffic = [
      { date: todayStr, views: siteStats.totalPageviews, visitors: siteStats.uniqueVisits }
    ];

    return {
      todayVisitors: siteStats.uniqueVisits,
      totalVisitors: siteStats.uniqueVisits,
      todayPageViews: siteStats.totalPageviews,
      totalArticleViews: totalArticleViews || siteStats.totalPageviews,
      publishedArticlesCount: publishedArticles.length,
      totalArticlesCount: articles.length,
      pendingCommentsCount: pendingComments.length,
      recentTraffic,
    };
  }
}

export const AnalyticsService = new AnalyticsServiceClass();
