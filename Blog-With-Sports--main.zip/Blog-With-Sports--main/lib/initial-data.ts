import { Article, Category, Author, Comment, SiteSettings } from './types';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'football',
    name: 'Football',
    slug: 'football',
    description: 'In-depth coverage, tactical analysis, and European and international football reporting.',
    status: 'active',
    order: 1,
  },
  {
    id: 'basketball',
    name: 'Basketball',
    slug: 'basketball',
    description: 'NBA breakdowns, player development analytics, and international hoops coverage.',
    status: 'active',
    order: 2,
  },
  {
    id: 'tennis',
    name: 'Tennis',
    slug: 'tennis',
    description: 'Grand Slam narratives, tactical baseline trends, and tour-level analysis.',
    status: 'active',
    order: 3,
  },
  {
    id: 'motorsport',
    name: 'Motorsport',
    slug: 'motorsport',
    description: 'Formula 1 technical debriefs, telemetry insights, and endurance racing coverage.',
    status: 'active',
    order: 4,
  },
  {
    id: 'cricket',
    name: 'Cricket',
    slug: 'cricket',
    description: 'Test match grit, ICC tournament deep-dives, and franchise league analytics.',
    status: 'active',
    order: 5,
  },
  {
    id: 'baseball',
    name: 'Baseball',
    slug: 'baseball',
    description: 'MLB analytics, pitching mechanics, and postseason race breakdowns.',
    status: 'active',
    order: 6,
  },
  {
    id: 'nfl',
    name: 'NFL',
    slug: 'nfl',
    description: 'Gridiron scheme dissections, quarterback progression reads, and draft scouting.',
    status: 'active',
    order: 7,
  },
  {
    id: 'other-sports',
    name: 'Other Sports',
    slug: 'other-sports',
    description: 'Olympic disciplines, marathon running, golf majors, and combat sports.',
    status: 'active',
    order: 8,
  },
];

export const INITIAL_AUTHORS: Author[] = [
  {
    id: 'marcus-vance',
    name: 'Marcus Vance',
    role: 'Senior European Football Correspondent',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80',
    bio: 'Marcus has covered European football and the UEFA Champions League for over a decade across London, Madrid, and Milan.',
  },
  {
    id: 'elena-rostova',
    name: 'Elena Rostova',
    role: 'Racquet Sports & Athletics Analyst',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=160&auto=format&fit=crop&q=80',
    bio: 'Former tour consultant specializing in biomechanics, court geometry, and high-performance sports physiology.',
  },
  {
    id: 'david-chen',
    name: 'David Chen',
    role: 'Motorsport & Aerodynamics Editor',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&auto=format&fit=crop&q=80',
    bio: 'Specializing in Formula 1 power unit regulations, telemetry analysis, and trackside engineering debriefs.',
  },
  {
    id: 'bws-editorial',
    name: 'BWS Editorial',
    role: 'Senior Desk & Research Team',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=160&auto=format&fit=crop&q=80',
    bio: 'The collaborative investigative and statistical journalism desk at Blog With Sports.',
  },
];

export const INITIAL_ARTICLES: Article[] = [];

export const INITIAL_COMMENTS: Comment[] = [];

export const INITIAL_SETTINGS: SiteSettings = {
  siteName: 'Blog With Sports',
  siteTagline: 'Independent sports stories, analysis and coverage from around the world.',
  siteDescription: 'Modern, clean, and lightweight international sports news, editorial analysis, and long-form journalism.',
  defaultAuthor: 'BWS Editorial',
  contactEmail: 'editorial@blogwithsports.com',
  editorialDeskLocation: 'London · New York · Dubai',
  defaultMetaTitle: 'Blog With Sports (BWS) — Independent Sports Stories & Analysis',
  defaultMetaDescription: 'Independent sports journalism covering European and international football, basketball, tennis, motorsport, and cricket with in-depth analysis.',
};
